package Kolokvium1.ednodimenzionalni;

import java.util.*;

public class zadaca2{

    static class Person {
        String nameSurname;
        int kniga1;
        int kniga2;
        int kniga3;

        public Person(String nameSurname, int kniga1, int kniga2, int kniga3) {
            this.nameSurname = nameSurname;
            this.kniga1 = kniga1;
            this.kniga2 = kniga2;
            this.kniga3 = kniga3;
        }

        @Override
        public String toString() {
            return nameSurname + " " + kniga1 + " " + kniga2 + " " + kniga3;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Queue<Person> q = new LinkedList<>();
        Queue<Person> q1 = new LinkedList<>();
        Queue<Person> q2 = new LinkedList<>();

        int n = sc.nextInt();

        for (int i=0; i<n; i++) {
            String name = sc.next() + " " + sc.next();
            int kniga1 = sc.nextInt();
            int kniga2 = sc.nextInt();
            int kniga3 = sc.nextInt();
            Person p = new Person(name, kniga1, kniga2, kniga3);

            if (kniga1 == 1) {
                q.add(p);
            }
            else if (kniga2 == 1) {
                q1.add(p);
            }
            else if (kniga3 == 1) {
                q2.add(p);
            }

        }

        while (!q.isEmpty()) {
            Person p = q.poll();
            if(p.kniga2 == 0 && p.kniga3 == 0) {
                System.out.println(p.nameSurname);
            }
            else if(p.kniga2 == 1) {
                q1.add(p);
            }
            else{
                q2.add(p);
            }
        }

        while (!q1.isEmpty()) {
            Person p = q1.poll();
            if(p.kniga3 == 0) {
                System.out.println(p.nameSurname);
            }
            else{
                q2.add(p);
            }
        }

        while(!q2.isEmpty()) {
            Person p = q2.poll();
            System.out.println(p.nameSurname);
        }

    }
}