package Kolokvium1.ednodimenzionalni;
import java.util.*;

public class sortRedica {
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);

       int n = sc.nextInt();
       Queue<Integer> q = new LinkedList<>();

       for (int i = 0; i < n; i++){
           q.add(sc.nextInt());
       }

       Stack<Integer> stack = new Stack<>();

       while(!q.isEmpty()){
            int razgleduvaj = q.poll();
            if (q.isEmpty()){
                break;
            }
            int nareden = q.peek();

            if (nareden < razgleduvaj) {
                stack.add(razgleduvaj);
            }
       }

       while(!stack.isEmpty()){
           int top = stack.pop();
           if (stack.isEmpty()){
               System.out.println("da");
               return;
           }
           int prethoden = stack.peek();

           if (top > prethoden){
               System.out.println("ne");
               return;
           }
       }

    }

}

/*


 */