package Kolokvium1.ednodimenzionalni;

import java.util.*;

public class queueKolokv {

    static public class Person {
        String name;
        int baranje;

        public Person(String name, int baranje) {
            this.name = name;
            this.baranje = baranje;
        }

        @Override
        public String toString() {
            return name + " " + baranje;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        Queue<Person> q = new LinkedList<>();

        for (int i = 0; i < n; i++) {
            String name = sc.next();
            int baranje = sc.nextInt();

            Person p = new Person(name, baranje);

            q.add(p);

        }
        while (!q.isEmpty()) {
            Person p1 = q.poll();

            if (p1.baranje != 1) {
                p1.baranje -= 1;
                q.add(p1);
            } else {
                System.out.println(p1.name);
            }
        }

    }
}
