package Kolokvium1.ednodimenzionalni;
import java.util.Scanner;
import java.util.Stack;

public class zadaca1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s;
        Stack<String> stack = new Stack<>();
        boolean flag = true;
        while(true){
            s = sc.nextLine();
            if (s.length() == 1 && s.charAt(0)=='x') {
                break;
            }else{
                if(s.startsWith("end")){
                    String function=s.substring(3);
                    if(stack.isEmpty() || !stack.peek().equals(function)){
                        flag=false;
                        break;
                    }else{
                        stack.pop();
                    }
                }else{
                    stack.push(s);
                }
            }

        }
        if(stack.isEmpty() && flag){
            System.out.println("Valid");
        }else{
            System.out.println("Invalid");
        }
    }
}