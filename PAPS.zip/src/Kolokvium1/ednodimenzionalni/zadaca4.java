package Kolokvium1.ednodimenzionalni;

import java.util.*;

public class zadaca4 {

    static class Person {
        String name;
        int docs;
        int index;
        int sredno;

        public Person(String name, int docs, int index, int sredno) {
            this.name = name;
            this.docs = docs;
            this.index = index;
            this.sredno = sredno;
        }

        @Override
        public String toString() {
            return name + " " + docs + " " + index + " " + sredno;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Queue<Person> q = new LinkedList<>();
        Queue<Person> q1 = new LinkedList<>();
        Queue<Person> q2 = new LinkedList<>();

        int n = sc.nextInt();

        for (int i = 0; i < n; i++) {
            String name = sc.next() + " " + sc.next();
            int docs = sc.nextInt();
            int index = sc.nextInt();
            int sredno = sc.nextInt();
            sc.nextLine();

            Person p = new Person(name, docs, index, sredno);

            if (p.docs == 1) {
                q.add(p);
            } else if (p.index == 1) {
                q1.add(p);
            } else if (p.sredno == 1) {
                q2.add(p);
            }
        }

        while (!q.isEmpty() || !q1.isEmpty() || !q2.isEmpty()) {



            if (!q.isEmpty()) {
                Person p = q.poll();
                if (p.index == 0 && p.sredno == 0) {
                    System.out.println(p.name);
                } else if (p.index == 1) {
                    q1.add(p);
                } else {
                    q2.add(p);
                }
            }

            if (!q1.isEmpty()) {
                Person p = q1.poll();
                if (p.sredno == 0) {
                    System.out.println(p.name);
                } else {
                    q2.add(p);
                }
            }

            if (!q2.isEmpty()) {
                Person p = q2.poll();
                System.out.println(p.name);
            }
        }
    }
}
