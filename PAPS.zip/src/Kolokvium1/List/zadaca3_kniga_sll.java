package Kolokvium1.List;
import java.util.Scanner;

// TODO: NAJIZMENICNO SPOJ LISTI

/*
    dadeni dva sll cij sto jazli sodrzat po eden priroden broj. Treba da se spojat dvete vo edna
    taka sto najizmenicno ke se dodavat dva jazli od prvata vo rez, pa prvite dva od vtorata
    pa slednite dva od prvata pa slednite dva od vtorata i taka natamu
    Za kraj jazlite sto ke ostanat treba da se dodadat na kraj prvo onie sto ostnale od prvata
    pa onie sto ostanale od vtorata
 */

public class zadaca3_kniga_sll {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        SLL<Integer> list1 = new SLL<Integer>();
        SLL<Integer> list2 = new SLL<Integer>();
        SLL<Integer> list3 = new SLL<Integer>();

        for (int i = 0; i < n; i++) {
            list1.insertLast(sc.nextInt());
        }

        int m = sc.nextInt();
        for (int i = 0; i < m; i++) {
            list2.insertLast(sc.nextInt());
        }

        SLLNode<Integer> current = list1.getFirst();
        SLLNode<Integer> current2 = list2.getFirst();
        while (current != null || current2 != null) {
            for (int i = 0; i < 2 && current!=null; i++) {
                list3.insertLast(current.element);
                current = current.succ;
            }

            for (int i=0; i<2 && current2!=null; i++) {
                list3.insertLast(current2.element);
                current2 = current2.succ;
            }
        }

        System.out.println(list3);

    }


    static class SLL<E> {
        private SLLNode<E> first;

        public SLL() {
            // Construct an empty SLL
            this.first = null;
        }

        public void deleteList() {
            first = null;
        }

        public int size() {
            int listSize = 0;
            SLLNode<E> tmp = first;
            while(tmp != null) {
                listSize++;
                tmp = tmp.succ;
            }
            return listSize;
        }

        @Override
        public String toString() {
            String ret = new String();
            if (first != null) {
                SLLNode<E> tmp = first;
                ret += tmp.element;
                while (tmp.succ != null) {
                    tmp = tmp.succ;
                    ret += "->" + tmp.element;
                }
            } else
//            MKD version
//            ret = "Prazna lista!!!";
                ret = "Empty list!!!";
            return ret;
        }

        public void insertFirst(E o) {
            SLLNode<E> ins = new SLLNode<E>(o, null);
            ins.succ = first;
            //SLLNode<E> ins = new SLLNode<E>(o, first);
            first = ins;
        }

        public void insertAfter(E o, SLLNode<E> node) {
            if (node != null) {
                SLLNode<E> ins = new SLLNode<E>(o, node.succ);
                node.succ = ins;
            } else {
//            MKD version
//            System.out.println("Dadenot jazol e null");
                System.out.println("Given node is null");
            }
        }
        public void insertBefore(E o, SLLNode<E> before) {

            if (first != null) {
                SLLNode<E> tmp = first;
                if(first==before){
                    this.insertFirst(o);
                    return;
                }
                //ako first!=before
                while (tmp.succ != before && tmp.succ!=null)
                    tmp = tmp.succ;
                if (tmp.succ == before) {
                    tmp.succ = new SLLNode<E>(o, before);;
                } else {
//                MKD version
//                System.out.println("Elementot ne postoi vo listata");
                    System.out.println("Element does not exist in the list");
                }
            } else {
//            MKD version
//            System.out.println("Listata e prazna");
                System.out.println("The list is empty");
            }
        }

        public void insertLast(E o) {
            if (first != null) {
                SLLNode<E> tmp = first;
                while (tmp.succ != null)
                    tmp = tmp.succ;
                tmp.succ = new SLLNode<E>(o, null);
            } else {
                insertFirst(o);
            }
        }

        public E deleteFirst() {
            if (first != null) {
                SLLNode<E> tmp = first;
                first = first.succ;
                return tmp.element;
            } else {
//            MKD version
//            System.out.println("Listata e prazna");
                System.out.println("The list is empty");
                return null;
            }
        }

        public E delete(SLLNode<E> node) {
            if (first != null) {
                SLLNode<E> tmp = first;
                if(first == node) {
                    return this.deleteFirst();
                }
                while (tmp.succ != node && tmp.succ.succ != null)
                    tmp = tmp.succ;
                if (tmp.succ == node) {
                    tmp.succ = tmp.succ.succ;
                    return node.element;
                } else {
//                MKD version
//                System.out.println("Elementot ne postoi vo listata");
                    System.out.println("Element does not exist in the list");
                    return null;
                }
            } else {
//            MKD version
//            System.out.println("Listata e prazna");
                System.out.println("The list is empty");
                return null;
            }

        }

        public SLLNode<E> getFirst() {
            return first;
        }

        public SLLNode<E> find(E o) {
            if (first != null) {
                SLLNode<E> tmp = first;
                while (!tmp.element.equals(o) && tmp.succ != null)
                    tmp = tmp.succ;
                if (tmp.element.equals(o)) {
                    return tmp;
                } else {
//                MKD version
//                System.out.println("Elementot ne postoi vo listata");
                    System.out.println("Element does not exist in the list");
                }
            } else {
//            MKD version
//            System.out.println("Listata e prazna");
                System.out.println("The list is empty");
            }
            return null;
        }

        public void merge (SLL<E> in){
            if (first != null) {
                SLLNode<E> tmp = first;
                while(tmp.succ != null)
                    tmp = tmp.succ;
                tmp.succ = in.getFirst();
            }
            else{
                first = in.getFirst();
            }
        }

        public void mirror() {
            if (first != null) {
                //m=nextsucc, p=tmp,q=next
                SLLNode<E> tmp = first;
                SLLNode<E> newsucc = null;
                SLLNode<E> next;

                while(tmp != null){
                    next = tmp.succ;
                    tmp.succ = newsucc;
                    newsucc = tmp;
                    tmp = next;
                }
                first = newsucc;
            }
        }
    }

    static class SLLNode<E> {
        protected E element;
        protected SLLNode<E> succ;

        public SLLNode(E elem, SLLNode<E> succ) {
            this.element = elem;
            this.succ = succ;
        }
    }

}
