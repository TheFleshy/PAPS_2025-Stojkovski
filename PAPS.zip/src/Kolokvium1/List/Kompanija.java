package Kolokvium1.List;

/*
Todo: Kolokviumska zadaca Ana Todorovska
 Podatocite za plati na vrabotenite vo edna kompanija privremeno se cuvaat vo ednostrana povrzana lista.
 Vo sekoj jazol se cuva edinstven ID na vrabotenio i negovata plata. Potrebno e da se ostranat site vraboteni so pomali
 plati od daden iznos, a ostatokot da se prikazat vo opagacki redosled vo odnos na id-to. Vo prv red e daden broj na vraboteni
 potoa najizmenicno se dadeni id i plata i vo posledniot red e iznosot vo odnos na koj ke se ostranuvat.
 Na izlez se pacati listata (ID, plata) vo opagacki redosled spored ID na sekoj od vrabotenite
 Dokolku nema vraboteni so plata pogolema od dadenata da se ispecati: nema


 TODO: ZADACATA NE KORISTE GENERICKI KLASI ZA SLL I SLLNODE TUKU IZMENENI SA I DODADENO E NESTO SO TREBA NIA SAMI DA GO NAPISEME I NESTO DA IZMENEME !


 3
 1111
 19000
 2222
 22000
 1155
 60000
 30000

 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Kompanija {

    public static void main(String[] args) throws IOException {
        SLL lista1 = new SLL();
        BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));

        String s = stdin.readLine();
        int n = Integer.parseInt(s);

        for (int i = 0; i < n; i++) {
            s = stdin.readLine();
            String s1 = stdin.readLine();
            lista1.insertLast(Integer.parseInt(s), Integer.parseInt(s1));
        }
        s = stdin.readLine();

        lista1 = lista1.brisi_pomali_od(Integer.parseInt(s));
        if (lista1 != null) {
            lista1 = lista1.sortiraj_opagacki();
            lista1.pecati(lista1);
        }
    }


    static class SLL<E> {
        private SLLNode<E> first;

        public SLL() {
            // Construct an empty SLL
            this.first = null;
        }

        public void deleteList() {
            first = null;
        }

        public int lenght() {
            int res;
            if (first != null) {
                SLLNode tmp = this.first;
                res = 1;
                while (tmp.succ != null) {
                    tmp = tmp.succ;
                    res++;
                }
                return res;
            } else {
                return 0;
            }
        }

        public void insertFirst(int id, int plata) {
            SLLNode<E> ins = new SLLNode<E>(id, plata, first);
            //SLLNode<E> ins = new SLLNode<E>(o, first);
            first = ins;
        }

        public void insertLast(int id, int plata) {
            if (first != null) {
                SLLNode<E> tmp = first;
                while (tmp.succ != null)
                    tmp = tmp.succ;
                SLLNode ins = new SLLNode<E>(id, plata, null);
                tmp.succ = ins;
            } else {
                insertFirst(id, plata);
            }
        }

        public void insertAfter(int id, int plata) {
            if (first != null) {
                SLLNode tmp = first;
                while (tmp.succ != null) {
                    tmp = tmp.succ;
                }
                SLLNode ins = new SLLNode<E>(id, plata, null);
                tmp.succ = ins;
            } else {
                insertFirst(id, plata);
            }
        }

        public SLLNode<E> getFirst() {
            return first;
        }

        public SLL brisi_pomali_od(int iznos) {
            SLLNode current = first;
            SLLNode prev = first;

            while (current != null) {
                if (current.plata < iznos) {
                    if (current == first) {
                        first = current.succ;
                        prev = first;
                        current = first;
                    } else {
                        prev.succ = current.succ;
                        current = current.succ;
                    }
                } else {
                    prev = current;
                    current = current.succ;
                }
            }
            return this;
        }

        public SLL sortiraj_opagacki() {
            // nekoj tip na bubble ke go opneme
            SLLNode node, prev1, pred2, tmp;

            for (int i = 0; i < lenght(); i++) {
                node = first.succ;
                prev1 = first;
                pred2 = prev1;

                while (node != null) {
                    if (prev1.id < node.id) {
                        tmp = node.succ;
                        node.succ = prev1;
                        prev1 = tmp;

                        if (prev1 == first) {
                            first = node;

                        } else {
                            pred2.succ = node;
                        }
                        pred2 = node;
                        node = tmp;
                    } else {
                        if (prev1 != first)
                            pred2 = pred2.succ;
                        prev1 = prev1.succ;
                        node = node.succ;
                    }
                }
            }
            return this;
        }

        public void pecati(SLL lista) {
            SLLNode p = lista.first;
            if (p == null) {
                System.out.println("nema");
                return;
            }
            while (p != null) {
                System.out.println(p.id + " " + p.plata);
                p = p.succ;
            }
        }

        public void merge(SLL<E> in) {
            if (first != null) {
                SLLNode<E> tmp = first;
                while (tmp.succ != null)
                    tmp = tmp.succ;
                tmp.succ = in.getFirst();
            } else {
                first = in.getFirst();
            }
        }

        public void mirror() {
            if (first != null) {
                //m=nextsucc, p=tmp,q=next
                SLLNode<E> tmp = first;
                SLLNode<E> newsucc = null;
                SLLNode<E> next;

                while (tmp != null) {
                    next = tmp.succ;
                    tmp.succ = newsucc;
                    newsucc = tmp;
                    tmp = next;
                }
                first = newsucc;
            }
        }
    }

    static class SLLNode<E> {
        protected int id;
        protected int plata;
        protected SLLNode<E> succ;

        public SLLNode(int id, int plata, SLLNode<E> succ) {
            this.id = id;
            this.plata = plata;
            this.succ = succ;
        }
    }
}
