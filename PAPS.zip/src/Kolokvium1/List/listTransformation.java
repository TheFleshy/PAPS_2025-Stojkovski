package Kolokvium1.List;

import java.util.Scanner;

public class listTransformation {


    public static void listTransformation(SLL<Integer> list) {
        SLL<Integer> parni = new SLL<Integer>();
        SLL<Integer> neparni = new SLL<Integer>();

        SLLNode<Integer> par = null;
        SLLNode<Integer> nep = null;

        SLLNode<Integer> tmp = list.getFirst();
        while (tmp != null) {
            SLLNode<Integer> nextNode = tmp.succ;
            tmp.succ = null;

            if(tmp.element % 2== 0){

                if (parni.first == null){
                    par = tmp;
                    parni.first = par;
                }else {
                    par.succ = tmp;
                    par = par.succ;
                }

            }else {
                if (neparni.first == null){
                    nep = tmp;
                    neparni.first = nep;
                }else {
                    nep.succ = tmp;
                    nep = nep.succ;
                }
            }
            tmp = nextNode;
        }

        System.out.println(neparni);
        System.out.println(parni);
    }


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SLL<Integer> list = new SLL<Integer>();
        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            list.insertLast(sc.nextInt());
        }
        listTransformation(list);
    }




    static class SLL<E> {
        private SLLNode<E> first;

        public SLL() {
            // Construct an empty SLL
            this.first = null;
        }

        public void deleteList() {
            first = null;
        }

        public int size() {
            int listSize = 0;
            SLLNode<E> tmp = first;
            while(tmp != null) {
                listSize++;
                tmp = tmp.succ;
            }
            return listSize;
        }

        @Override
        public String toString() {
            String ret = new String();
            if (first != null) {
                SLLNode<E> tmp = first;
                ret += tmp.element;
                while (tmp.succ != null) {
                    tmp = tmp.succ;
                    ret += "->" + tmp.element;
                }
            } else
//            MKD version
//            ret = "Prazna lista!!!";
                ret = "Empty list!!!";
            return ret;
        }

        public void insertFirst(E o) {
            SLLNode<E> ins = new SLLNode<E>(o, null);
            ins.succ = first;
            //SLLNode<E> ins = new SLLNode<E>(o, first);
            first = ins;
        }

        public void insertAfter(E o, SLLNode<E> node) {
            if (node != null) {
                SLLNode<E> ins = new SLLNode<E>(o, node.succ);
                node.succ = ins;
            } else {
//            MKD version
//            System.out.println("Dadenot jazol e null");
                System.out.println("Given node is null");
            }
        }
        public void insertBefore(E o, SLLNode<E> before) {

            if (first != null) {
                SLLNode<E> tmp = first;
                if(first==before){
                    this.insertFirst(o);
                    return;
                }
                //ako first!=before
                while (tmp.succ != before && tmp.succ!=null)
                    tmp = tmp.succ;
                if (tmp.succ == before) {
                    tmp.succ = new SLLNode<E>(o, before);;
                } else {
//                MKD version
//                System.out.println("Elementot ne postoi vo listata");
                    System.out.println("Element does not exist in the list");
                }
            } else {
//            MKD version
//            System.out.println("Listata e prazna");
                System.out.println("The list is empty");
            }
        }

        public void insertLast(E o) {
            if (first != null) {
                SLLNode<E> tmp = first;
                while (tmp.succ != null)
                    tmp = tmp.succ;
                tmp.succ = new SLLNode<E>(o, null);
            } else {
                insertFirst(o);
            }
        }

        public E deleteFirst() {
            if (first != null) {
                SLLNode<E> tmp = first;
                first = first.succ;
                return tmp.element;
            } else {
//            MKD version
//            System.out.println("Listata e prazna");
                System.out.println("The list is empty");
                return null;
            }
        }

        public E delete(SLLNode<E> node) {
            if (first != null) {
                SLLNode<E> tmp = first;
                if(first == node) {
                    return this.deleteFirst();
                }
                while (tmp.succ != node && tmp.succ.succ != null)
                    tmp = tmp.succ;
                if (tmp.succ == node) {
                    tmp.succ = tmp.succ.succ;
                    return node.element;
                } else {
//                MKD version
//                System.out.println("Elementot ne postoi vo listata");
                    System.out.println("Element does not exist in the list");
                    return null;
                }
            } else {
//            MKD version
//            System.out.println("Listata e prazna");
                System.out.println("The list is empty");
                return null;
            }

        }

        public SLLNode<E> getFirst() {
            return first;
        }

        public SLLNode<E> find(E o) {
            if (first != null) {
                SLLNode<E> tmp = first;
                while (!tmp.element.equals(o) && tmp.succ != null)
                    tmp = tmp.succ;
                if (tmp.element.equals(o)) {
                    return tmp;
                } else {
//                MKD version
//                System.out.println("Elementot ne postoi vo listata");
                    System.out.println("Element does not exist in the list");
                }
            } else {
//            MKD version
//            System.out.println("Listata e prazna");
                System.out.println("The list is empty");
            }
            return null;
        }

        public void merge (SLL<E> in){
            if (first != null) {
                SLLNode<E> tmp = first;
                while(tmp.succ != null)
                    tmp = tmp.succ;
                tmp.succ = in.getFirst();
            }
            else{
                first = in.getFirst();
            }
        }

        public void mirror() {
            if (first != null) {
                //m=nextsucc, p=tmp,q=next
                SLLNode<E> tmp = first;
                SLLNode<E> newsucc = null;
                SLLNode<E> next;

                while(tmp != null){
                    next = tmp.succ;
                    tmp.succ = newsucc;
                    newsucc = tmp;
                    tmp = next;
                }
                first = newsucc;
            }
        }
    }

    static class SLLNode<E> {
        protected E element;
        protected SLLNode<E> succ;

        public SLLNode(E elem, SLLNode<E> succ) {
            this.element = elem;
            this.succ = succ;
        }
    }
}
