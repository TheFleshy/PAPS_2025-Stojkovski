package Kolokvium1.List;

import java.util.Scanner;

// TODO: RAZDELI MIN-MAX LISTA

// da se najdat elementi so najgolema i najmala vrednost, pa da se podeli listata na dve
// ednostrani povrzani listi t.s vo prvata lista da se smestat site jazli koi sodrzat broevi
// pobliski do najmaliot elem otkolku so najgolemiot element
// a vo vtorata site jazli koi sodrzat broevi pobliski do najgolemiot. Dokolku elementot e na isto
// rastojanie od najmalio i najgolemio se smestuva vo lista so najmalio.

public class zadaca1_kniga_sll {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        SLL<Integer> list = new SLL<Integer>();
        int n = sc.nextInt();
        sc.nextLine();
        for (int i = 0; i < n; i++) {
            list.insertLast(sc.nextInt());
        }

        SLLNode<Integer> current = list.getFirst();

        // TODO: find min
        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;

        while (current != null) {
            int value = current.element;
            if (value > max) {
                max = value;
            }
            if (value < min) {
                min = value;
            }
            current = current.succ;
        }

        SLL<Integer> listMali = new SLL<Integer>();
        SLL<Integer> listGolemi = new SLL<Integer>();

        //todo: da se smestat broevi pobliski do najmaliot
        current = list.getFirst();
        while (current != null) {
            int value = current.element;
            if (Math.abs(value - min) <= Math.abs(value - max)) {
                listMali.insertLast(value);
            } else {
                listGolemi.insertLast(value);
            }
            current = current.succ;
        }

        System.out.println(listMali);
        System.out.println(listGolemi);

    }

    /*
    9
    1 5 7 3 2 9 4 8 6

    izlez:

    1 5 3 2 4
    7 9 8 6
     */

    static class SLL<E> {
        private SLLNode<E> first;

        public SLL() {
            // Construct an empty SLL
            this.first = null;
        }

        public void deleteList() {
            first = null;
        }

        public int size() {
            int listSize = 0;
            SLLNode<E> tmp = first;
            while (tmp != null) {
                listSize++;
                tmp = tmp.succ;
            }
            return listSize;
        }

        @Override
        public String toString() {
            String ret = new String();
            if (first != null) {
                SLLNode<E> tmp = first;
                ret += tmp.element;
                while (tmp.succ != null) {
                    tmp = tmp.succ;
                    ret += "->" + tmp.element;
                }
            } else
//            MKD version
//            ret = "Prazna lista!!!";
                ret = "Empty list!!!";
            return ret;
        }

        public void insertFirst(E o) {
            SLLNode<E> ins = new SLLNode<E>(o, null);
            ins.succ = first;
            //SLLNode<E> ins = new SLLNode<E>(o, first);
            first = ins;
        }

        public void insertAfter(E o, SLLNode<E> node) {
            if (node != null) {
                SLLNode<E> ins = new SLLNode<E>(o, node.succ);
                node.succ = ins;
            } else {
//            MKD version
//            System.out.println("Dadenot jazol e null");
                System.out.println("Given node is null");
            }
        }

        public void insertBefore(E o, SLLNode<E> before) {

            if (first != null) {
                SLLNode<E> tmp = first;
                if (first == before) {
                    this.insertFirst(o);
                    return;
                }
                //ako first!=before
                while (tmp.succ != before && tmp.succ != null)
                    tmp = tmp.succ;
                if (tmp.succ == before) {
                    tmp.succ = new SLLNode<E>(o, before);
                    ;
                } else {
//                MKD version
//                System.out.println("Elementot ne postoi vo listata");
                    System.out.println("Element does not exist in the list");
                }
            } else {
//            MKD version
//            System.out.println("Listata e prazna");
                System.out.println("The list is empty");
            }
        }

        public void insertLast(E o) {
            if (first != null) {
                SLLNode<E> tmp = first;
                while (tmp.succ != null)
                    tmp = tmp.succ;
                tmp.succ = new SLLNode<E>(o, null);
            } else {
                insertFirst(o);
            }
        }

        public E deleteFirst() {
            if (first != null) {
                SLLNode<E> tmp = first;
                first = first.succ;
                return tmp.element;
            } else {
//            MKD version
//            System.out.println("Listata e prazna");
                System.out.println("The list is empty");
                return null;
            }
        }

        public E delete(SLLNode<E> node) {
            if (first != null) {
                SLLNode<E> tmp = first;
                if (first == node) {
                    return this.deleteFirst();
                }
                while (tmp.succ != node && tmp.succ.succ != null)
                    tmp = tmp.succ;
                if (tmp.succ == node) {
                    tmp.succ = tmp.succ.succ;
                    return node.element;
                } else {
//                MKD version
//                System.out.println("Elementot ne postoi vo listata");
                    System.out.println("Element does not exist in the list");
                    return null;
                }
            } else {
//            MKD version
//            System.out.println("Listata e prazna");
                System.out.println("The list is empty");
                return null;
            }

        }

        public SLLNode<E> getFirst() {
            return first;
        }

        public SLLNode<E> find(E o) {
            if (first != null) {
                SLLNode<E> tmp = first;
                while (!tmp.element.equals(o) && tmp.succ != null)
                    tmp = tmp.succ;
                if (tmp.element.equals(o)) {
                    return tmp;
                } else {
//                MKD version
//                System.out.println("Elementot ne postoi vo listata");
                    System.out.println("Element does not exist in the list");
                }
            } else {
//            MKD version
//            System.out.println("Listata e prazna");
                System.out.println("The list is empty");
            }
            return null;
        }

        public void merge(SLL<E> in) {
            if (first != null) {
                SLLNode<E> tmp = first;
                while (tmp.succ != null)
                    tmp = tmp.succ;
                tmp.succ = in.getFirst();
            } else {
                first = in.getFirst();
            }
        }

        public void mirror() {
            if (first != null) {
                //m=nextsucc, p=tmp,q=next
                SLLNode<E> tmp = first;
                SLLNode<E> newsucc = null;
                SLLNode<E> next;

                while (tmp != null) {
                    next = tmp.succ;
                    tmp.succ = newsucc;
                    newsucc = tmp;
                    tmp = next;
                }
                first = newsucc;
            }
        }
    }

    static class SLLNode<E> {
        protected E element;
        protected SLLNode<E> succ;

        public SLLNode(E elem, SLLNode<E> succ) {
            this.element = elem;
            this.succ = succ;
        }
    }

}
