package Kolokvium1.Labs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class binomni_koefpolin_paskalovtriag {
    public static void main(String[] args) throws IOException {
        System.out.println(binomal(3, 3));
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(bf.readLine());
        int m = Integer.parseInt(bf.readLine());
        int[][] bc = new int[n + 1][m + 1];

        for (int i = 0; i <= n; i++) {
            bc[i][0] = 1;
        }
        for (int j = 1; j < n; j++) {
            bc[j][j + 1] = 1;
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                bc[i][j] = bc[i - 1][j - 1] + bc[i - 1][j];
            }
        }
        System.out.println(bc[n][m]);
    }

    static int binomal(int n, int k) {
        if (k == 0) return 1;
        if (n == 0) return 0;
        return binomal(n - 1, k) + binomal(n - 1, k - 1);

    }


}
