package Kolokvium1.Labs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class rabotni_zadaci {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        int m = in.nextInt();

        List<Integer> zadaci = new ArrayList<Integer>();
        for (int i = 0; i < n; i++) {
            zadaci.add(in.nextInt());
        }

        int denovi = 0;
        int slobodni = 0;
        while (!zadaci.isEmpty()) {
            for (int i = 0; i < m; i++) {
                int casovi = 8;
                int j = 0;
                while (casovi > 0 && j < zadaci.size()) {
                    if (casovi - zadaci.get(j) >= 0) {
                        casovi -= zadaci.get(j);
                        zadaci.remove(j);
                        j--;
                    }

                    j++;
                }

                slobodni += casovi;
            }

            denovi++;
        }

        System.out.println(denovi + " " + slobodni);
    }
}

//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Scanner;
//
//public class lab01 {
//    public static void main(String[] args) {
//
//    }
//}
//
//
