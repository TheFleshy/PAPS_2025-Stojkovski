package Kolokvium1.Labs;
import java.util.*;

public class svetilki {

    static int minimum (int m, int n, int [] niza){
//        int [] osvetleni = new int[n+1];
        int rezultat = 0;

        int i=3;
        int j=0;

        while(i< n +2){
            if (i <= n ){
                if (niza[j++] == i){
//                    osvetleni[i] = i;
                    rezultat++;
                    i+=5;
                }
            }else {
                i--;
            }
        }
        return rezultat;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt();  // dolzina na ulica
        int n = sc.nextInt();  // mesta kade mozat da se postavat ulicni svetilki

        int [] niza = new int[m];
        for (int i = 0; i < m; i++) {
            niza[i] = sc.nextInt();
        }
        System.out.println(minimum(m, n, niza));

    }
}

