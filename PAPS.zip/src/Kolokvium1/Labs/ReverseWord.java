package Kolokvium1.Labs;

// За даден збор кој се внесува од стандарден влез, да се испечати истиот превртен. На влез во првиот ред се дава број на зборови кои ќе се внесуваат.
// Во наредните линии се внесуваат самите зборови.

import java.util.Scanner;

public class ReverseWord {

    public static void printReversed(String word) {
        StringBuilder reversed = new StringBuilder(word);
        System.out.println(reversed.reverse().toString());
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int nWord = sc.nextInt();
        sc.nextLine();
        for (int i = 0; i < nWord; i++) {
            String word = sc.nextLine();
            printReversed(word);
        }

    }
}
