package Kolokvium1.Labs;

import java.util.Arrays;
import java.util.Scanner;

public class vozovi {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int [] arrivals = new int[n];
        int [] departures = new int[n];

        for (int i = 0; i < n; i++) {
            arrivals[i] = sc.nextInt();
            departures[i] = sc.nextInt();
        }

        Arrays.sort(arrivals);
        Arrays.sort(departures);

        int numberPlatforms = 0;
        int maxPlatforms = 0;

        int i=0; int j=0;

        while (i<n && j<n) {
            if (arrivals[i] < departures[j]) {
                numberPlatforms++;
                maxPlatforms = Math.max(maxPlatforms, numberPlatforms);
                i++;
            }else{
                numberPlatforms--;
                j++;
            }
        }
        System.out.println(maxPlatforms);
    }
}
