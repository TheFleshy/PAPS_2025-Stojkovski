package Kolokvium1.Labs;
import java.util.NoSuchElementException;
import java.util.Scanner;

class ArrayQueue<E> {
    // Redicata e pretstavena na sledniot nacin:
    // length go sodrzi brojot na elementi.
    // Ako length > 0, togash elementite na redicata se zachuvani vo elems[front...rear-1]
    // Ako rear > front, togash vo  elems[front...maxlength-1] i elems[0...rear-1]
    E[] elems;
    int length, front, rear;

    // Konstruktor ...

    @SuppressWarnings("unchecked")
    public ArrayQueue(int maxlength) {
        elems = (E[]) new Object[maxlength];
        clear();
    }

    public boolean isEmpty() {
        // Vrakja true ako i samo ako redicata e prazena.
        return (length == 0);
    }

    public int size() {
        // Ja vrakja dolzinata na redicata.
        return length;
    }

    public E peek() {
        // Go vrakja elementot na vrvot t.e. pocetokot od redicata.
        if (length > 0)
            return elems[front];
        else
            throw new NoSuchElementException();
    }

    public void clear() {
        // Ja prazni redicata.
        length = 0;
        front = rear = 0;  // arbitrary
    }

    public void enqueue(E x) {
        // Go dodava x na kraj od redicata.
        if (length == elems.length)
            throw new NoSuchElementException();
        elems[rear++] = x;
        if (rear == elems.length) rear = 0;
        length++;
    }

    public E dequeue() {
        // Go otstranuva i vrakja pochetniot element na redicata.
        if (length > 0) {
            E frontmost = elems[front];
            elems[front++] = null;
            if (front == elems.length) front = 0;
            length--;
            return frontmost;
        } else
            throw new NoSuchElementException();
    }
}

class Person{
    String name, surname;
    int prva, vtora, treta;
    int tezina;

    public Person(String name, String surname, int prva, int vtora, int treta) {
        this.name = name + ' ' + surname;
        this.prva = prva;
        this.vtora = vtora;
        this.treta = treta;
        this.tezina = 0;
    }
}

public class queue_bib_red {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Person []lugje = new Person[n];
        for(int i=0; i<n; i++){
            String name = sc.next();
            String surname = sc.next();
            sc.nextLine();
            int prva = sc.nextInt();
            int vtora = sc.nextInt();
            int treta = sc.nextInt();
            Person p = new Person(name, surname, prva, vtora, treta);
            lugje[i] = p;
        }
        for(int i=0; i<n; i++){
            if(lugje[i].treta == 1){
                lugje[i].tezina += 10;
            }
            if(lugje[i].vtora == 1){
                lugje[i].tezina += 5;
            }
            if(lugje[i].prva == 1){
                lugje[i].tezina += 1;
            }
        }
        for(int i=0; i<n; i++){
            for(int j=i; j<n; j++){
                if(lugje[i].tezina > lugje[j].tezina){
                    Person covek = lugje[j];
                    lugje[j] = lugje[i];
                    lugje[i] = covek;
                }
            }
        }
        for(int i=0; i<n; i++){
            System.out.println(lugje[i].name);
        }
    }
}