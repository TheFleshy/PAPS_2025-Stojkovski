package Kolokvium1.Labs;

import java.util.Scanner;

public class find_smallest_devideandcon {
    public static void main(String[] args) {
        int[] a = new int[]{8, 2, 4, 9, 3, 6, 7, 5};
        int [] r = najdi(a, 0, 7);
        System.out.println(r[0] + " " + r[1]);
    }

    static int[] najdi(int[] a, int l, int r) {
        int[] rezultat = new int[2];
        if (l == r) {
            rezultat = new int[]{a[l], 10000};
            return rezultat;
        }
        int mid = (l + r) / 2;
        int[] r1 = najdi(a, l, mid);
        int[] r2 = najdi(a, mid + 1, r);

        if (r1[0] < r2[0]) {
            rezultat[0] = r1[0];
            if (r1[1] < r2[0]) {
                rezultat[1] = r1[1];
            } else {
                rezultat[1] = r2[0];
            }
        } else {
            rezultat[0] = r2[0];
            if (r1[0] < r2[1]) {
                rezultat[1] = r1[0];
            } else {
                rezultat[1] = r2[1];
            }
        }
        return rezultat;
    }

}
