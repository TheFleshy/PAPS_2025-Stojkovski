package Kolokvium1.Labs;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Arrays;

public class SmallestNumberWithSum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(), m = sc.nextInt();

        int pocetok = 1;
        for(int i = 0; i < n - 1; i++) {
            pocetok *= 10;
        }

        boolean flag = true;
        int kraj = pocetok * 10 - 1;
        for(int i = pocetok; i < kraj; i++){
            int temp = i;
            int zbir = 0;
            for(int j = 0; j < n; j++){
                zbir += temp % 10;
                temp /= 10;
            }
            if(zbir == m){
                System.out.println(i);
                flag = false;
                break;
            }
        }

        if(flag){
            System.out.println("Ne postoi");
        }

//        Scanner sc = new Scanner(System.in);
//        int n = sc.nextInt(), m = sc.nextInt();
////        int[] cifri = new int[n];
//        List<Integer> cifri = new ArrayList<>();
//
//        cifri.add(1);
//        m-=1;
//        while (m>0){
//            if (m>=9){
//                cifri.add(9);
//                m-=9;
//            }else {
//                cifri.add(m);
//                m = 0;
//            }
//        }
//        int promenliva = n-cifri.size();
//        for (int i = 1; i < 1+promenliva; i++) {
//
//        }
    }
}


