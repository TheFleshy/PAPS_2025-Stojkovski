package Kolokvium1.Labs;

import java.util.ArrayList;
import java.util.Scanner;

public class zalutani {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Integer> niza = new ArrayList<>();
        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            niza.add(sc.nextInt());
        }

        int c = 0;
        int k = 0;

        int [][] pecati = new int[10][10];
        for (int i = 1; i < n; i++) {
            if (niza.get(i) < niza.get(i-1)) {
                c++;
                int broj = 0;
                for (int j = i; j > 0; j--) {
                    if (niza.get(i) < niza.get(j-1)) {
                        broj++;
                    }
                }
                pecati[k][0] = niza.get(i);
                pecati[k][1] = broj;
                k++;
            }
        }
        System.out.println(c);
        for (int i = 0; i < k; i++) {
            System.out.println(pecati[i][0] + " " + pecati[i][1]);
        }
    }
}

