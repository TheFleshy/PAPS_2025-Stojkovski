package Kolokvium1.Labs;
import java.util.*;


public class zadaci {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int [] timeTaken = new int[n];
        int [] paid = new int[n];

        for (int i = 0; i < n; i++) {
            timeTaken[i] = sc.nextInt();
            paid[i] = sc.nextInt();
        }

        double [] earnings = new double[n];

        for (int i = 0; i < n; i++) {
            earnings[i] = (double) paid[i] / timeTaken[i];
        }

        for (int i = 0; i < n-1; i++) {
            for (int j = i; j < n; j++) {
                if (earnings[i] < earnings[j]) {
                    double temp = earnings[j];
                    earnings[j] = earnings[i];
                    earnings[i] = temp;

                    int tmp2 = timeTaken[j];
                    timeTaken[j] = timeTaken[i];
                    timeTaken[i] = tmp2;
                }
            }
        }

        int currentHours = 0;
        double maxEarning = 0;
        int remaingHours = 40;

        for (int i = 0; i < n; i++) {
            if (currentHours < 40){
                if ((remaingHours-timeTaken[i]) > 0) {
                    maxEarning += (timeTaken[i] * earnings[i]);
                    currentHours += timeTaken[i];
                    remaingHours = remaingHours - timeTaken[i];
                }
                else{
                    currentHours += remaingHours;
                    maxEarning += (remaingHours * earnings[i]);
                }
            }
        }
        System.out.println ((int)maxEarning);

    }
}
