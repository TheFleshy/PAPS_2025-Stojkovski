package Kolokvium1.Labs;

import java.util.Scanner;

public class svetilki_miki {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int M = scanner.nextInt();
        int N = scanner.nextInt();
        int[] niza = new int[M];

        for(int i=0;i<M;i++){
            niza[i] = scanner.nextInt();
        }

        int [] osvetleni = new int[N+1];
        int i=3, j=0;

        int rezultat = 0;
        while(i < N+2){
            if(i>=N){
                rezultat++;

                System.out.println(rezultat);
                return;
            }
            if(osvetleni[i] == 0 && i <= N){
                osvetleni[i] = 1;
                i+=5;
                rezultat++;
            }else{
                i--;
            }
        }

        if(i==13){
            if(N==10){
                rezultat--;
            }
            rezultat++;
        }
        System.out.println(rezultat);

    }
}
