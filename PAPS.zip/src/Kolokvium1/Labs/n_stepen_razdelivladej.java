package Kolokvium1.Labs;

import java.util.Scanner;

public class n_stepen_razdelivladej {
    public static void main(String[] args) {
        System.out.println(stepen(5, 2));

    }

    static int stepen (int broj, int stepen_pomosen){
        int pom;
        if (stepen_pomosen == 0){
            return 1;
        }else if (stepen_pomosen %2 == 0){
            pom = stepen(broj, stepen_pomosen/2);
            return pom * pom;
        }
        else {
            pom = stepen(broj, stepen_pomosen/2);
            return broj*pom * pom;
        }
    }
}
