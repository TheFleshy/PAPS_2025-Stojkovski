package Kolokvium1.Labs;

import java.util.Scanner;

public class ZadaciKnapsack {
    static void sort(int[]vreme, int [] profit, int N){
        for(int i=0; i<N; i++){
            for(int j=i+1; j<N; j++){
                double odnosI = (double)vreme[i] / profit[i];
                double odnosJ = (double)vreme[j] / profit[j];
                if(odnosI > odnosJ){
                    int tVreme = vreme[i];
                    vreme[i] = vreme[j];
                    vreme[j] = tVreme;

                    int tProfit = profit[i];
                    profit[i] = profit[j];
                    profit[j] = tProfit;
                }
            }
        }
    }
    static int knapsack(int [] vreme, int [] profit, int N){
        int kapacitet = 40;
        int maksProfit = 0;
        for(int i=0; i<N; i++){
            if(kapacitet == 0){
                break;
            }
            if(vreme[i]<= kapacitet){
                kapacitet -= vreme[i];
                maksProfit += profit[i];
            } else{
                double razlika = (double)kapacitet /vreme[i];
                kapacitet = 0;
                maksProfit += (double)profit[i]*razlika;
            }
        }
        return maksProfit;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        int []vreme = new int[N];
        int []profit = new int[N];
        for(int i=0; i<N; i++){
            vreme[i] = sc.nextInt();
            profit[i] = sc.nextInt();
        }

        sort(vreme, profit, N);

        System.out.println(knapsack(vreme, profit, N));
    }
}
