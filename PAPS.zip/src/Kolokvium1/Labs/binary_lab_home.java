package Kolokvium1.Labs;
import java.util.Scanner;



public class binary_lab_home {

    int binarySearch (int [] a, int l, int r, int x) {
        while (l <= r) {
            int mid = (l + r) / 2;
            if (a[mid] == x) {
                return mid;
            }else if (a[mid] < x) {
                l = mid + 1;
            }else {
                r = mid - 1;
            }
        }
        return -1; //
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        int m = sc.nextInt();
        sc.nextLine();

        int [] niza = new int[n];

        for (int i = 0; i < n; i++) {
            niza[i] = sc.nextInt();
        }

        binary_lab_home obj = new binary_lab_home();
        int result = obj.binarySearch(niza, 0, n - 1, m);

        if (result == -1) {
            System.out.println("Ne postoi");
        }else {
            System.out.println(result);
        }


    }
}
