package Kolokvium1.Labs;

import java.util.*;

public class devide_con {
    public static void main(String[] args) {
//        int [] a = new int []{8,2,4,9,3,6,7,5};
//        mergesort(a, 0, 7);
//        for (int i = 0; i < 8; i++) {
//            System.out.print(a[i] + " ");
//        }
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int [] niza = new int[n];
        for (int i = 0; i < n; i++) {
            niza[i] = sc.nextInt();
        }

        mergesort(niza, 0, niza.length - 1);

        for (int i = n-1; i >= 0; i--) {
            System.out.print(niza[i]);
        }

//        System.out.println(Arrays.toString(a));

    }

    // merge(a[], b[]) kade a od l do mid, b od mid+1 do r
    static void merge (int [] a, int l, int mid, int r){
        // od l do r (srednatocka : mid)
        // a[l,mid] ... a[mid+1, r]
        // 1 3      2 4
        // 1 2 3 4

        int [] temp = new int[100];
        int i = l;
        int j = mid + 1;
        int k = 0;
        while(i<=mid && j<= r){
            if (a[i]<a[j]){
                temp[k++] = a[i++];
            }else {
                temp[k++] = a[j++];
            }
        }

        while (i<=mid){
            temp[k++] = a[i++];
        }
        while (j<=r){
            temp[k++] = a[j++];
        }

        for (int p = 0; p<r-l+1; p++){
            a[l+p] = temp[p];
        }
    }

    static void mergesort(int [] a, int l, int r){
        if(l==r){
            return;
        }
        int mid = (l+r)/2;
        mergesort(a, l, mid);
        mergesort(a, mid+1, r);
        merge(a, l, mid, r);
    }


}
