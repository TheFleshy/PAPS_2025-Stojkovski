package Kolokvium1.Labs;

import java.util.Scanner;

public class knapsack_dinamicko {

    public static int knapsack(int[] tezina, int[] profit, int C) {
        int n = tezina.length;
        int[][] matrix = new int[n + 1][C + 1];

        for (int i = 0; i <= n; i++) {
            matrix[i][0] = 0;
        }

        for (int j = 0; j <= C; j++) {
            matrix[0][j] = 0;
        }

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= C; j++) {
                if (tezina[i - 1] <= j) {
                    matrix[i][j] = Math.max(matrix[i - 1][j], matrix[i - 1][j - tezina[i - 1]] + profit[i - 1]);
                } else {
                    matrix[i][j] = matrix[i - 1][j];
                }
            }
        }
        return matrix[n][C];
    }

    public static void main(String[] args) {

        int C = 50;
        int[] p = {60, 100, 120};
        int[] w = {10, 20, 30};

        System.out.println(knapsack_dinamicko.knapsack(w, p, C));
    }


}
