package Kolokvium1.Labs;

import java.util.*;

public class paricki {
    public static void main(String[] args) {
        int[] moneti = new int[5];
        System.out.println(broj_na_moneti_v1(13));
        System.out.println(broj_na_moneti_v2(13, new int[]{1, 2, 5, 8, 1}, 5, moneti));
    }

    static int broj_na_moneti_v1(int suma) {
        int rezultat = 100000;
        for (int m1 = 0; m1 <= (suma / 50); m1++) {
            for (int m2 = 0; m2 <= (suma / 10); m2++) {
                for (int m3 = 0; m3 <= (suma / 5); m3++) {
                    for (int m4 = 0; m4 <= (suma / 2); m4++) {
                        for (int m5 = 0; m5 <= suma; m5++) {
                            int pom = m1 * 50 + m2 * 10 + m3 * 5 + m4 * 2 + m5;
                            if (pom == suma) {
                                int broj_paricki = m1 + m2 + m3 + m4 + m5;
                                if (rezultat > broj_paricki) {
                                    rezultat = broj_paricki;
                                }
                            }
                        }
                    }
                }
            }
        }
        return rezultat;
    }

    static int broj_na_moneti_v2(int suma, int[] paricki, int n, int[] moneti) {
        sortiaj_paricki(paricki, n);
        int i = 0;
        int br = 0;
        while (suma > 0) {
            moneti[i] = suma / paricki[i];
            suma -= moneti[i] * paricki[i];
            br += moneti[i];
            i++;
        }

        while (i < n) {
            paricki[i] = 0;
            i++;
        }
        return br;
    }

    ;

    static void sortiaj_paricki(int paricki[], int n) {
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (paricki[i] < paricki[j]) {
                    int temp = paricki[i];
                    paricki[i] = paricki[j];
                    paricki[j] = temp;
                }
            }
        }
    }

}
