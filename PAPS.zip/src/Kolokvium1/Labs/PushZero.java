package Kolokvium1.Labs;

// За дадена низа од случајни броеви кои се внесуваат од стандарден влез, да се направи преместување на сите нули на почеток на низата.
// На стандарден излез да се испечати трансформираната низа.
// input: 12
//        1 9 8 4 0 0 2 7 0 6 0 9
// Result:
//        Transformiranata niza e:
//        0 0 0 0 1 9 8 4 2 7 6 9


import java.util.Scanner;

public class PushZero {
    static void pushZerosToBeginning(int [] arr, int n)
    {
        int j = n-1;

        // pomestuvanje na ne-nulti elementi
        for (int i = n-1; i >= 0; i--){
            if (arr[i] != 0){
                arr[j] = arr[i];
                j--;
            }
        }

        while (j >= 0){
            arr[j] = 0;
            j--;
        }
    }

    public static void main (String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int [] arr = new int[n];
        for (int i=0; i<n; i++){
            arr[i] = sc.nextInt();
        }
        pushZerosToBeginning(arr, n);

        System.out.println("Transformiranata niza e: ");
        for (int i=0; i<n; i++){
            System.out.print(arr[i] + " ");
        }
    }
}