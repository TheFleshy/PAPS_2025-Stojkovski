package Kolokvium1.Labs;

import java.util.*;

public class knapsack_student_kufer {
    public static void main(String[] args) {
        int[] t  = new int [] {18,15,10};
        int[] p = new int [] {25,24,15};
        float [] x = new float [3];
        System.out.println(profit(p, t, 3, 20, x));
    }

    static void sort (int [] p, int [] t, int n){
        for (int i = 0; i < n-1; i++){
            for (int j = i+1; j < n; j++){
                float p1 = (float) p[i]/t[i];
                float p2 = (float) p[j]/t[j];
                if (p1 < p2){
                    int tmpP = p[i];
                    int tmpT = t[i];
                    p[i] = p[j];
                    t[i] = t[j];
                    t[j] = tmpT;
                    p[j] = tmpP;
                }
            }
        }
    }

    static float profit (int [] p, int [] t, int n, float C, float [] x){
        sort(p, t, n);
        for (int i = 0; i < n; i++){
            x[i] = 0;
        }
        float profit = 0;
        for (int i = 0; i < n; i++){
            if(C>t[i]){
                x[i] = 1;
                C-=t[i];
                profit += p[i];
            }else {
                x[i] = (float)C/t[i];
                profit += p[i] * x[i];
                C = 0;
                break;
            }
        }
        return profit;
    }
}
