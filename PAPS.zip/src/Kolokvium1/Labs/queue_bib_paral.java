//package Kolokvium1.Labs;
//
//import java.util.NoSuchElementException;
//import java.util.Scanner;
//
//interface Queue<E> {
//    // Elementi na redicata se objekti od proizvolen tip.
//    // Metodi za pristap:
//    public boolean isEmpty();
//    // Vrakja true ako i samo ako redicata e prazena.
//
//    public int size();
//    // Ja vrakja dolzinata na redicata.
//
//    public E peek();
//    // Go vrakja elementot na vrvot t.e. pocetokot od redicata.
//
//    // Metodi za transformacija:
//
//    public void clear();
//    // Ja prazni redicata.
//
//    public void enqueue(E x);
//    // Go dodava x na kraj od redicata.
//
//    public E dequeue();
//    // Go otstranuva i vrakja pochetniot element na redicata.
//}
//
//class LinkedQueue<E> implements Queue<E> {
//    // Redicata e pretstavena na sledniot nacin:
//    // length go sodrzi brojot na elementi.
//    // Elementite se zachuvuvaat vo jazli dod SLL
//    // front i rear se linkovi do prviot i posledniot jazel soodvetno.
//    SLLNode<E> front, rear;
//    int length;
//
//    // Konstruktor ...
//    public LinkedQueue() {
//        clear();
//    }
//
//    public boolean isEmpty() {
//        // Vrakja true ako i samo ako redicata e prazena.
//        return (length == 0);
//    }
//
//    public int size() {
//        // Ja vrakja dolzinata na redicata.
//        return length;
//    }
//
//    public E peek() {
//        // Go vrakja elementot na vrvot t.e. pocetokot od redicata.
//        if (front == null)
//            throw new NoSuchElementException();
//        return front.element;
//    }
//
//    public void clear() {
//        // Ja prazni redicata.
//        front = rear = null;
//        length = 0;
//    }
//
//    public void enqueue(E x) {
//        // Go dodava x na kraj od redicata.
//        SLLNode<E> latest = new SLLNode<E>(x, null);
//        if (rear != null) {
//            rear.succ = latest;
//            rear = latest;
//        } else
//            front = rear = latest;
//        length++;
//    }
//
//    public E dequeue() {
//        // Go otstranuva i vrakja pochetniot element na redicata.
//        if (front != null) {
//            E frontmost = front.element;
//            front = front.succ;
//            if (front == null) rear = null;
//            length--;
//            return frontmost;
//        } else
//            throw new NoSuchElementException();
//    }
//
//}
//
//class Student {
//    public String name;
//    public int nauka;
//    public int fantastika;
//    public int istorija;
//
//    Student(String name, int document, int index, int sredno) {
//        this.nauka = document;
//        this.fantastika = index;
//        this.istorija = sredno;
//        this.name = name;
//    }
//
//}
//
//public class queue_bib_paral {
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        int n = sc.nextInt();
//        sc.nextLine();
//        //n broj na studenti
//        LinkedQueue<Studentt> row = new LinkedQueue<>();
//        for (int i = 0; i < n; i++) {
//            String name = sc.nextLine();
//            int nau = sc.nextInt();
//            int fant = sc.nextInt();
//            int ist = sc.nextInt();
//            sc.nextLine();
//            row.enqueue(new Studentt(name, nau, fant, ist));
//        }
//        LinkedQueue<Studentt> shalterNauk = new LinkedQueue<>();
//        LinkedQueue<Studentt> shalterFant = new LinkedQueue<>();
//        LinkedQueue<Studentt> shalterIst = new LinkedQueue<>();
//        //
//        for (int i = 0; i < n; i++) {
//            Studentt s = row.dequeue();
//            if (sz.nauka == 1) {
//                shalterNauk.enqueue(s);
//            } else if (s.fantastika == 1) {
//                shalterFant.enqueue(s);
//            } else if (s.istorija == 1) {
//                shalterIst.enqueue(s);
//            }
//        }
//        for (int i = 0; i < n; i++) {
//            //za nauka
//            for (int j = 0; j < 2; j++) {
//                if (!shalterNauk.isEmpty()) {
//                    Studentt s = shalterNauk.dequeue();
//                    //od 1 doc sea e 0
//                    if (s.fantastika == 1) {
//                        shalterFant.enqueue(s);
//                    } else if (s.istorija == 1) {
//                        shalterIst.enqueue(s);
//                    } else {
//                        System.out.println(s.name);
//                    }
//                }
//            }
//            //za fantastika
//            for (int j = 0; j < 1; j++) {
//                if (!shalterFant.isEmpty()) {
//                    Studentt s = shalterFant.dequeue();
//                    //od 1 doc sea e 0
//                    if (s.istorija == 1) {
//                        shalterIst.enqueue(s);
//                    } else {
//                        System.out.println(s.name);
//                    }
//                }
//            }
//            //za istorija
//            for (int j = 0; j < 2; j++) {
//                if (!shalterIst.isEmpty()) {
//                    Studentt s = shalterIst.dequeue();
//                    //od 1 doc sea e 0
//                    System.out.println(s.name);
//
//                }
//            }
//        }
//    }
//}