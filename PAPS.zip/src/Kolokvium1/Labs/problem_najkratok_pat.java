package Kolokvium1.Labs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class problem_najkratok_pat {
    public static void main(String[] args) throws IOException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        int[][] cost = new int[n][n];
        int[] tax = new int[n];
        int[] best = new int[n];
        //vnesi elementi
        for (int i = 0; i < n; i++) {
            System.out.println("Vnesi taksa");
            tax[i] = Integer.parseInt(br.readLine());
            for (int j = i + 1; j < n; j++) {
                System.out.println("Vnesi cena na bilet od " + i + " do " + j);
                cost[i][j] = Integer.parseInt(br.readLine());
            }
        }
        best[0] = tax[0];
        for (int i = 1; i < n; i++) {
            best[i] = 10000;
            for (int j = 0; j < n; j++)
                best[i] = Math.min(best[i], best[j] + cost[j][i] + tax[i]);
        }
        System.out.println(best[n - 1]);

    }


}
