package Kolokvium1.Labs;

//todo: find max number of stones, that robot can collect

public class problem_max_sum_robot {
    public static void main(String[] args) {

        int a[][] = new int[5][5];
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                a[i][j] = i+j;
            }
        }
        int [][] best = maksimalen_zbir(a, 5, 5);
        for(int i=0; i<5; i++){
            for(int j=0; j<5; j++){
                System.out.print(best[i][j]);
            }
            System.out.println();
        }


    }
    static int [][] maksimalen_zbir (int [][] a, int n, int m){
        int [] [] best = new int [n][m];
        best[0][0] = a[0][0];
        for (int i = 1; i < n; i++){
            best[i][0] = a[i][0] + best[i-1][0];
        }
        for (int i = 1; i < m; i++){
            best[0][i] = best[0][i-1] + a[0][i];
        }

        for (int i = 1; i < n; i++){
            for (int j = 1; j < m; j++){
                best[i][j] = Math.max(best[i-1][j], best[i][j-1]) + a[i][j];
            }
        }
        return best;
    }

}
