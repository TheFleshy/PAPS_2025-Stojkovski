package Kolokvium1.Labs;

/* TODO: Napisete algoritam koj ke ja pronajde najdolgata "Zaednicka" podsekvenca na dva stringa x[] y[] i
    i ke dade koja e nejzinata dolzina
    pr. najdolga "zaednicka" podsekvenca na strinogivte :
    ggcaccacg acggcggatacg e ---> ggcaacg
*/

public class zaednicka_podsekvenca {

    public static int[][] lenghtsArray(String x, String y) {
        int n = x.length();
        int m = y.length();
        int[][] lcs = new int[n + 1][m + 1];
        for (int i = 0; i <= n; i++) {
            lcs[i][0] = 0;
        }

        for (int j = 0; j <= m; j++) {
            lcs[0][j] = 0;
        }

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (x.charAt(i - 1) == y.charAt(j - 1)) {
                    lcs[i][j] = lcs[i - 1][j - 1] + 1;
                } else {
                    lcs[i][j] = Math.max(lcs[i - 1][j], lcs[i][j - 1]);
                }
            }
        }
        return lcs;
    }

    public static int longestCommonSequenceLength(String x, String y) {
        return lenghtsArray(x, y)[x.length()][y.length()];
    }

    public static String longestCommonSequence(String x, String y) {
        int n = x.length();
        int m = y.length();
        int[][] lcs = lenghtsArray(x, y);

        char[] result = new char[Math.max(n, m)];
        int lenght = 0;
        int i = n;
        int j = m;
        while (i != 0 && j != 0) {
            if (x.charAt(i - 1) == y.charAt(j - 1)) {
                result[lenght++] = x.charAt(i - 1);
                i--;
                j--;
            } else {
                if (lcs[i][j] == lcs[i - 1][j]) {
                    i--;
                } else {
                    j--;
                }
            }
        }
        String res = "";
        for (i = 0; i < lenght; i++) {
            res += result[lenght - i - 1];
        }
        return res;
    }

    public static void main(String[] args) {
        String x = "ggcaccacg";
        String y = "acggcggatacg";

        System.out.println(longestCommonSequenceLength(x, y));
        System.out.println(longestCommonSequence(x, y));
    }


}
