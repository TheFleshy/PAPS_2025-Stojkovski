///*
//Студентска служба е посетена од студентите со цел да приложат/земат документи. Студентот може да приложи документи,
//да побара да си го земе индексот или пак да побара да си ги земе документите од средно.
//Кога студентската служба ќе започне со работа се услужуваат студенти од сите три типа паралелно, но исто така сите три шалтера не одат со иста брзина па услужувањето е со следниот редослед
//(два студента што ги приложуваат документите, па три студенти што сакаат да си го земат индексот, па еден студент што сака да си ги земе документите од средно).
//Доколку студент чека ред за повеќе услуги кај студентската служба, тој чека ред првин во редицата за приложување на документи,
//потоа во редицата за земање на индекс и на крај во редицата за земање на документи од средно.
//
//Влез: Во првата линија е даден број на студенти кои имаат дојдено за да бидат услужени од студентската служба.
//Потоа 4 редици се внесуваат за секој студент, каде првата линија е име на студент, а во останатите 3 редици се внесува дали има потреба од дадена услуга
//(приложување документи, земање на индекс, земање на документи од средно соодветно), каде 1 значи дека има потреба од услуга од тој тип, 0 значи дека нема потреба од услуга од тој тип.
//
//Излез: Испечати го редоследот на студентите по редослед како завршуваат со сите услуги од студенстката служба.
// */
//package Kolokvium1.Labs;
//
//import java.util.Scanner;
//
//class Studentt {
//    public String name;
//    public int document;
//    public int index;
//    public int srednodocs;
//
//    Studentt(String name, int document, int index, int sredno) {
//        this.document = document;
//        this.index = index;
//        this.srednodocs = sredno;
//        this.name = name;
//    }
//
//}
//
//public class queue_sluzba {
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        int n = sc.nextInt();
//        sc.nextLine();
//        //n broj na studenti
//        LinkedQueue<Studentt> row = new LinkedQueue<>();
//        for (int i = 0; i < n; i++) {
//            String name = sc.nextLine();
//            int doc = sc.nextInt();
//            int index = sc.nextInt();
//            int sredno = sc.nextInt();
//            sc.nextLine();
//            row.enqueue(new Studentt(name, doc, index, sredno));
//        }
//        LinkedQueue<Studentt> shalterDocs = new LinkedQueue<>();
//        LinkedQueue<Studentt> shalterIndex = new LinkedQueue<>();
//        LinkedQueue<Studentt> shalterSrednoDocs = new LinkedQueue<>();
//        //
//        for (int i = 0; i < n; i++) {
//            Studentt s = row.dequeue();
//            if (s.document == 1) {
//                shalterDocs.enqueue(s);
//            } else if (s.index == 1) {
//                shalterIndex.enqueue(s);
//            } else if (s.srednodocs == 1) {
//                shalterSrednoDocs.enqueue(s);
//            }
//        }
//        for (int i = 0; i < n; i++) {
//            //za doc
//            for (int j = 0; j < 2; j++) {
//                if (!shalterDocs.isEmpty()) {
//                    Studentt s = shalterDocs.dequeue();
//                    //od 1 doc sea e 0
//                    if (s.index == 1) {
//                        shalterIndex.enqueue(s);
//                    } else if (s.srednodocs == 1) {
//                        shalterSrednoDocs.enqueue(s);
//                    } else {
//                        System.out.println(s.name);
//                    }
//                }
//            }
//            //za index
//            for (int j = 0; j < 1; j++) {
//                if (!shalterIndex.isEmpty()) {
//                    Studentt s = shalterIndex.dequeue();
//                    //od 1 doc sea e 0
//                    if (s.srednodocs == 1) {
//                        shalterSrednoDocs.enqueue(s);
//                    } else {
//                        System.out.println(s.name);
//                    }
//                }
//            }
//            //za srednodocs
//            for (int j = 0; j < 2; j++) {
//                if (!shalterSrednoDocs.isEmpty()) {
//                    Studentt s = shalterSrednoDocs.dequeue();
//                    //od 1 doc sea e 0
//                    System.out.println(s.name);
//
//                }
//            }
//        }
//    }
//}
////package Kolokvium1.Labs;
////import java.util.NoSuchElementException;
////import java.util.Scanner;
////
////class ArrayQueue<E> {
////    // Redicata e pretstavena na sledniot nacin:
////    // length go sodrzi brojot na elementi.
////    // Ako length > 0, togash elementite na redicata se zachuvani vo elems[front...rear-1]
////    // Ako rear > front, togash vo  elems[front...maxlength-1] i elems[0...rear-1]
////    E[] elems;
////    int length, front, rear;
////
////    // Konstruktor ...
////
////    @SuppressWarnings("unchecked")
////    public ArrayQueue(int maxlength) {
////        elems = (E[]) new Object[maxlength];
////        clear();
////    }
////
////    public boolean isEmpty() {
////        // Vrakja true ako i samo ako redicata e prazena.
////        return (length == 0);
////    }
////
////    public int size() {
////        // Ja vrakja dolzinata na redicata.
////        return length;
////    }
////
////    public E peek() {
////        // Go vrakja elementot na vrvot t.e. pocetokot od redicata.
////        if (length > 0)
////            return elems[front];
////        else
////            throw new NoSuchElementException();
////    }
////
////    public void clear() {
////        // Ja prazni redicata.
////        length = 0;
////        front = rear = 0;  // arbitrary
////    }
////
////    public void enqueue(E x) {
////        // Go dodava x na kraj od redicata.
////        if (length == elems.length)
////            throw new NoSuchElementException();
////        elems[rear++] = x;
////        if (rear == elems.length) rear = 0;
////        length++;
////    }
////
////    public E dequeue() {
////        // Go otstranuva i vrakja pochetniot element na redicata.
////        if (length > 0) {
////            E frontmost = elems[front];
////            elems[front++] = null;
////            if (front == elems.length) front = 0;
////            length--;
////            return frontmost;
////        } else
////            throw new NoSuchElementException();
////    }
////}
////
////class Person{
////    String name, surname;
////    int Kolokvium1.prva, vtora, treta;
////    int tezina;
////
////    public Person(String name, String surname, int Kolokvium1.prva, int vtora, int treta) {
////        this.name = name + ' ' + surname;
////        this.Kolokvium1.prva = Kolokvium1.prva;
////        this.vtora = vtora;
////        this.treta = treta;
////        this.tezina = 0;
////    }
////}
////
////public class queue_sluzba {
////    public static void main(String[] args) {
////        Scanner sc = new Scanner(System.in);
////        int n = sc.nextInt();
////        Person lugje[] = new Person[n];
////        for(int i=0; i<n; i++){
////            String name = sc.next();
////            String surname = sc.next();
////            sc.nextLine();
////            int Kolokvium1.prva = sc.nextInt();
////            int vtora = sc.nextInt();
////            int treta = sc.nextInt();
////            Person p = new Person(name, surname, Kolokvium1.prva, vtora, treta);
////            lugje[i] = p;
////        }
////        for(int i=0; i<n; i++){
////            if(lugje[i].treta == 1){
////                lugje[i].tezina += 10;
////            }
////            if(lugje[i].vtora == 1){
////                lugje[i].tezina += 5;
////            }
////            if(lugje[i].Kolokvium1.prva == 1){
////                lugje[i].tezina += 1;
////            }
////        }
////        for(int i=0; i<n; i++){
////            for(int j=i; j<n; j++){
////                if(lugje[i].tezina > lugje[j].tezina){
////                    Person covek = lugje[j];
////                    lugje[j] = lugje[i];
////                    lugje[i] = covek;
////                }
////            }
////        }
////        for(int i=0; i<n; i++){
////            System.out.println(lugje[i].name);
////        }
////    }
////}