//package Aud;
//
//import java.util.ArrayList;
//import java.util.Map;
//import java.util.HashMap;
//import java.util.List;
//
//public class TestHashJava {
//
//    public static void main(String[] args) {
//        Map<Vaccine, List<String>> map = new HashMap<>();
//        Vaccine vaccine1 = new Vaccine(1, "PHY");
//        Vaccine vaccine2 = new Vaccine(2, "PHY");
//        Vaccine vaccine3 = new Vaccine(1, "AZ");
//        Vaccine vaccine4 = new Vaccine(2, "AZ");
//
//        map.put(vaccine1, new ArrayList<String>());
//        map.put(vaccine2, new ArrayList<String>());
//        map.put(vaccine3, new ArrayList<String>());
//        map.put(vaccine4, new ArrayList<String>());
//
//        map.get(vaccine1).add("John");
//        map.get(vaccine1).add("Ana");
//        map.get(vaccine1).add("Peter");
//        map.get(vaccine1).add("Tom");
//
//        map.get(vaccine1).add("John 2");
//        map.get(vaccine2).add("Ana 2");
//        map.get(vaccine2).add("Peter 2");
//        map.get(vaccine2).add("Tom 2");
//
//        map.get(vaccine3).add("John 3");
//        map.get(vaccine3).add("Ana 3");
//        map.get(vaccine3).add("Peter 3");
//        map.get(vaccine3).add("Tom 3");
//
//        map.get(vaccine4).add("Tom 4");
//
//        System.out.println(map);
//    }
//
//}
