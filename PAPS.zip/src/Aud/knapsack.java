package Aud;

public class knapsack {

    private static void sort(int[] p, int[] w, int n) {     // nekoj bubblesort ke napraeme
        int tmpP, tmpW;
        int ratioI, ratioJ;

        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                ratioI = (int) ((float) p[i] / w[i]);
                ratioJ = (int) ((float)p[j] / w[j]);

                if (ratioI < ratioJ) {
                    tmpP = p[i];
                    p[i] = p[j];
                    p[j] = tmpP;

                    tmpW = w[i];
                    w[i] = w[j];
                    w[j] = tmpW;
                }
            }
        }
    }

    //p[] profits
    // w[] weights
    // C - capacity
    // x - result vector

    public static float fractionalKnapsack(int[] p, int[] w, float C, int n, float[] x) {
        sort(p, w, n);

        float profit = 0;
        for (int i = 0; i < n; i++) {
            x[i] = 0;
        }

        for (int i = 0; i < n; i++) {
            if (x[i] < C) {
                C -= w[i];
                profit += p[i];
                x[i] = 1;
            }else {
                profit += (C / (float) w[i]) * p[i];
                x[i] = C / (float) w[i];
                C = 0;
                break;
            }
        }
        return profit;
    }


    public static void main(String[] args) {
        float C = 20;
        int n = 3;
        int[] p = {25, 24, 15};
        int[] w = {18, 15, 10};

        float[] x = new float[3];

        System.out.println(fractionalKnapsack(p, w, C, n, x));
    }
}
