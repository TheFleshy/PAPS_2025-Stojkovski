package Aud;

public class TwoSmallestDivideAndConqueror {

    public static TwoSmallest findTwoSmallest(int [] array, int l, int r) {
        if (l == r){
            return new TwoSmallest(array[l], Integer.MAX_VALUE);
        }

        int middle = (l+r)/2;

        TwoSmallest r1 = findTwoSmallest(array, l, middle);
        TwoSmallest r2 = findTwoSmallest(array, middle+1, r);

        TwoSmallest result = new TwoSmallest();

        if (r1.a < r2.a){
            result.a = r1.a;

            if (r1.b < r2.a){
                result.b = r1.b;
            }else result.b = r2.a;
        }
        else {
            result.a = r2.a;

            if (r2.b < r1.a){
                result.b = r2.b;
            }else result.b = r1.a;
        }
        return result;
    }

    public static void main(String[] args) {
        int [] array = {9,2,4,6,12,8,7,3,1,5};

        TwoSmallest twoSmallest = TwoSmallestDivideAndConqueror.findTwoSmallest(array, 0, 9);
        System.out.println(twoSmallest.a + " " + twoSmallest.b);
    }

}
