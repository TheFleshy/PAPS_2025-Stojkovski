package Aud;

//// TODO: VAKCINI NESTO - Ana
//
//import java.util.Objects;
//
//public class Vaccine {
//
//    private int dose;
//    private String name;
//
//    public Vaccine(int dose, String name) {
//        this.dose = dose;
//        this.name = name;
//    }
//
//    @Override
//    public String toString() {
//        return "Vaccine{" +
//                "dose=" + dose +
//                ", name='" + name + '\'' +
//                '}';
//    }
//
//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        Vaccine vaccine = (Vaccine) o;
//        return dose == vaccine.dose && Objects.equals(name, vaccine.name);
//    }
//
//    @Override
//    public int hashCode() {
//        return Objects.hash(dose, name);
//    }
//}
import java.util.*;

class CBHT<K, V> {
    private class Entry<K, V> {
        K key;
        V value;
        Entry<K, V> next;

        Entry(K key, V value, Entry<K, V> next) {
            this.key = key;
            this.value = value;
            this.next = next;
        }
    }

    private Entry<K, V>[] buckets;

    @SuppressWarnings("unchecked")
    public CBHT(int size) {
        buckets = (Entry<K, V>[]) new Entry[size];
    }

    private int hash(K key) {
        return Math.abs(key.hashCode()) % buckets.length;
    }

    public V search(K key) {
        int index = hash(key);
        for (Entry<K, V> e = buckets[index]; e != null; e = e.next) {
            if (e.key.equals(key)) {
                return e.value;
            }
        }
        return null;
    }

    public void insert(K key, V value) {
        int index = hash(key);
        for (Entry<K, V> e = buckets[index]; e != null; e = e.next) {
            if (e.key.equals(key)) {
                e.value = value; // Update existing value
                return;
            }
        }
        buckets[index] = new Entry<>(key, value, buckets[index]);
    }

    public void delete(K key) {
        int index = hash(key);
        Entry<K, V> prev = null;
        for (Entry<K, V> e = buckets[index]; e != null; e = e.next) {
            if (e.key.equals(key)) {
                if (prev == null) {
                    buckets[index] = e.next;
                } else {
                    prev.next = e.next;
                }
                return;
            }
            prev = e;
        }
    }
}




class Person {
    String ime;
    String prezime;
    int budzet;
    String ipAdresa;
    String vreme; // in format "HH:mm"
    String grad;
    int cena;

    public Person(String ime, String prezime, int budzet, String ipAdresa, String vreme, String grad, int cena) {
        this.ime = ime;
        this.prezime = prezime;
        this.budzet = budzet;
        this.ipAdresa = ipAdresa;
        this.vreme = vreme;
        this.grad = grad;
        this.cena = cena;
    }

    public int getTimeInMinutes() {
        String[] parts = vreme.split(":");
        return Integer.parseInt(parts[0]) * 60 + Integer.parseInt(parts[1]);
    }

    @Override
    public String toString() {
        return ime + " " + prezime + " with budget " + budzet + " and spent " + cena + " at " + grad;
    }
}

public class Vaccine {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Читање на бројот на редови
        int n = scanner.nextInt();
        scanner.nextLine();

        CBHT<String, Person> gradToBestPerson = new CBHT<>(101);
        CBHT<String, Integer> gradToCount = new CBHT<>(101);

        // Читање на првите N редови
        for (int i = 0; i < n; i++) {
            String line = scanner.nextLine();
            String[] parts = line.split(" ");
            String ime = parts[0];
            String prezime = parts[1];
            int budzet = Integer.parseInt(parts[2]);
            String ipAdresa = parts[3];
            String vreme = parts[4];
            String grad = parts[5];
            int cena = Integer.parseInt(parts[6]);

            Person person = new Person(ime, prezime, budzet, ipAdresa, vreme, grad, cena);

            // Ажурирање на gradToBestPerson
            Person bestPerson = gradToBestPerson.search(grad);
            if (bestPerson == null || person.cena > bestPerson.cena ||
                    (person.cena == bestPerson.cena && person.getTimeInMinutes() < bestPerson.getTimeInMinutes())) {
                gradToBestPerson.insert(grad, person);
            }

            // Ажурирање на gradToCount
            if (person.getTimeInMinutes() > 11 * 60 + 59) {
                Integer count = gradToCount.search(grad);
                gradToCount.insert(grad, (count == null ? 1 : count + 1));
            }
        }

        // Читање на бројот на тест редови
        int m = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < m; i++) {
            String testGrad = scanner.nextLine();

            // Прв излез: целосната информација за најдобриот Person
            Person bestPerson = gradToBestPerson.search(testGrad);
            if (bestPerson != null) {
                System.out.println(bestPerson);
            } else {
                System.out.println("No users found for " + testGrad);
            }

            // Втор излез: бројот на лица што ги исполнуваат условите
            Integer count = gradToCount.search(testGrad);
            System.out.println(count == null ? 0 : count);
        }

        scanner.close();
    }
}

