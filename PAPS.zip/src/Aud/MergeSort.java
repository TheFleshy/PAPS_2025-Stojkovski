package Aud;

// TODO Divide and conquer (razdeli i vladej)

public class MergeSort {

    //will merge two sorted arrays
    private void merge(int[] niza, int l, int middle, int r) {
        int[] tmp = new int[100]; // temp store sorted elements
        int k = 0, i = l, j = middle + 1;
        int numElems = r - l + 1;

        while ((i <= middle) && (j <= r)) {
            if (niza[i] < niza[j]){
                tmp[k] = niza[i];
                i++;
            }else {
                tmp[k] = niza[j];
                j++;
            }
            k++;
        }

        while (i <= middle) {
            tmp[k] = niza[i];
            i++;
            k++;
        }

        while (j <= r) {
            tmp[k] = niza[j];
            j++;
            k++;
        }

        for (k=0; k<numElems; k++) {
            niza[l+k] = tmp[k];
        }

    }

    private void mergeSort(int[] niza, int l, int r) {
        if (l == r) {
            return;
        }

        int middle = (l + r) / 2;
        mergeSort(niza, l, middle);
        mergeSort(niza, middle + 1, r);
        merge(niza, l, middle, r);
    }

    public static void main(String[] args) {
        int[] niza = {1, 7, 8, 4, 5, 6, 2, 2, 0, -6, 7};
         MergeSort mergeSort = new MergeSort();
         mergeSort.mergeSort(niza, 0, 10);

        for (int i = 0; i < niza.length; i++) {
            System.out.print(niza[i] + " ");
        }

    }
}
