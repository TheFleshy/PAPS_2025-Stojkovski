package Aud.hesh;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;
/*
За различни градови дадени се мерењата на температурата (степени Целзиусови) во одредени временски интервали. Ваша задача е за даден град да се наjде наjтоплиот период од денот.
Влез: Во првиот ред од влезот е даден броjот на мерења 𝑁 (𝑁 <= 10000), а во секоj нареден ред е даден прво градот, потоа почеток на интервал, краj на интервал и температурата разделени со
празно место.
Во последниот ред е даден градот за коj треба да наjдете наjтопол период од денот и истиот
период да се испечати. Сложеноста на оваа операциjа треба да биде O(1).
Излез: Наjтоплиот период од денот за даден град. Да се испечати во следниов формат: G: HH:MM – XX:YY Z, каде што G е градот, HH:MM e почетокот на интервалот, XX:YY е краjот на интервалот, а Z e температурата во степени Целзиусови.
 */


public class Temperature {

    static class OBHT<K extends Comparable<K>, E> {

        // An object of class OBHT is an open-bucket hash table, containing entries
        // of class MapEntry.
        private MapEntry<K, E>[] buckets;

        // buckets[b] is null if bucket b has never been occupied.
        // buckets[b] is former if bucket b is formerly-occupied
        // by an entry that has since been deleted (and not yet replaced).

        static final int NONE = -1; // ... distinct from any bucket index.

        @SuppressWarnings({"rawtypes", "unchecked"})
        private static final MapEntry former = new MapEntry(null, null);
        // This guarantees that, for any genuine entry e,
        // e.key.equals(former.key) returns false.

        private int occupancy = 0;
        // ... number of occupied or formerly-occupied buckets in this OBHT.

        @SuppressWarnings("unchecked")
        public OBHT(int m) {
            // Construct an empty OBHT with m buckets.
            buckets = (MapEntry<K, E>[]) new MapEntry[m];
        }


        private int hash(K key) {
            // Translate key to an index of the array buckets.
            return Math.abs(key.hashCode()) % buckets.length;
        }


        public int search(K targetKey) {
            // Find which if any bucket of this OBHT is occupied by an entry whose key
            // is equal to targetKey. Return the index of that bucket.
            int b = hash(targetKey);

            for (int n_search = 0; n_search < buckets.length; n_search++) {
                MapEntry<K, E> currEntry = buckets[b];
                if (currEntry == null) return NONE;
                else if (currEntry.key.equals(targetKey)) return b;
                else b = (b + 1) % buckets.length;
            }
            return NONE;
        }

        public MapEntry<K, E> getBucket(int bucket) {
            return buckets[bucket];
        }


        public void insert(K key, E val) {
            // Insert the entry <key, val> into this OBHT.
            MapEntry<K, E> newEntry = new MapEntry<K, E>(key, val);
            int b = hash(key);
            int n_search = 0;
            Integer free_position = null;
            Integer existing_position = null;
            while (n_search < buckets.length) {
                MapEntry<K, E> currEntry = buckets[b];
                if (currEntry == null) {
                    if (free_position == null) free_position = b;
                    break;
                } else if (key.equals(currEntry.key)) {
                    existing_position = b;
                    break;
                } else {
                    if (currEntry == former && free_position == null) {
                        free_position = b;
                    }
                    b = (b + 1) % buckets.length;
                    n_search++;
                }
            }
            if (existing_position != null)
                buckets[existing_position] = newEntry;
            else if (free_position != null) {
                buckets[free_position] = newEntry;
                if (++occupancy == buckets.length) {
                    System.out.println("Hash tabelata e polna!!!");
                }
            } else {
                // failed to insert, table was already full
            }
        }


        @SuppressWarnings("unchecked")
        public void delete(K key) {
            // Delete the entry (if any) whose key is equal to key from this OBHT.
            int b = hash(key);
            int n_search = 0;
            while (n_search < buckets.length) {
                MapEntry<K, E> currEntry = buckets[b];
                if (currEntry == null) return;
                else if (currEntry.key.equals(key)) {
                    buckets[b] = former;
                    return;
                } else {
                    b = (b + 1) % buckets.length;
                    n_search++;
                }
            }
        }


        public String toString() {
            String temp = "";
            for (int i = 0; i < buckets.length; i++) {
                temp += i + ":";
                if (buckets[i] == null)
                    temp += "\n";
                else if (buckets[i] == former)
                    temp += "former\n";
                else
                    temp += buckets[i] + "\n";
            }
            return temp;
        }


        public OBHT<K, E> clone() {
            OBHT<K, E> copy = new OBHT<K, E>(buckets.length);
            for (int i = 0; i < buckets.length; i++) {
                MapEntry<K, E> e = buckets[i];
                if (e != null && e != former)
                    copy.buckets[i] = new MapEntry<K, E>(e.key, e.value);
                else
                    copy.buckets[i] = e;
            }
            return copy;
        }
    }

    static class CBHT<K extends Comparable<K>, E> {

        // An object of class CBHT is a closed-bucket hash table, containing
        // entries of class MapEntry.
        private SLLNode<MapEntry<K, E>>[] buckets;

        @SuppressWarnings("unchecked")
        public CBHT(int m) {
            // Construct an empty CBHT with m buckets.
            buckets = (SLLNode<MapEntry<K, E>>[]) new SLLNode[m];
        }

        private int hash(K key) {
            // Translate key to an index of the array buckets.
            return Math.abs(key.hashCode()) % buckets.length;
        }

        public SLLNode<MapEntry<K, E>> search(K targetKey) {
            // Find which if any node of this CBHT contains an entry whose key is equal to targetKey.
            // Return a link to that node (or null if there is none).
            int b = hash(targetKey);
            SLLNode<MapEntry<K, E>> currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(targetKey)) return currNode;
                else currNode = currNode.succ;
            }
            return null;
        }

        public void insert(K key, E val) {
            // Insert the entry <key, val> into this CBHT.
            // If entry with same key exists, overwrite it.
            MapEntry<K, E> newEntry = new MapEntry<>(key, val);
            int b = hash(key);
            SLLNode<MapEntry<K, E>> currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(key)) {
                    // Make newEntry replace the existing entry ...
                    currNode.element = newEntry;
                    return;
                } else currNode = currNode.succ;
            }
            // Insert newEntry at the front of the SLL in bucket b ...
            buckets[b] = new SLLNode<>(newEntry, buckets[b]);
        }

        public void delete(K key) {
            // Delete the entry (if any) whose key is equal to key from this CBHT.
            int b = hash(key);
            SLLNode<MapEntry<K, E>> predNode = null, currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(key)) {
                    if (predNode == null) buckets[b] = currNode.succ;
                    else predNode.succ = currNode.succ;
                    return;
                } else {
                    predNode = currNode;
                    currNode = currNode.succ;
                }
            }
        }

        public String toString() {
            String temp = "";
            for (int i = 0; i < buckets.length; i++) {
                temp += i + ":";
                SLLNode<MapEntry<K, E>> curr = buckets[i];
                while (curr != null) {
                    temp += curr.element.toString() + " ";
                    curr = curr.succ;
                }
                temp += "\n";
            }
            return temp;
        }
    }


    static class MapEntry<K extends Comparable<K>, E> {
        // Each MapEntry object is a pair consisting of a key (a Comparable object)
        // and a value (an arbitrary object).
        K key;
        E value;

        public MapEntry(K key, E val) {
            this.key = key;
            this.value = val;
        }

        public String toString() {
            return "<" + key + "," + value + ">";
        }
    }

    static class SLLNode<E> {
        protected E element;
        protected SLLNode<E> succ;

        public SLLNode(E elem, SLLNode<E> succ) {
            this.element = elem;
            this.succ = succ;
        }

        @Override
        public String toString() {
            return element.toString();
        }
    }

    /*
4
Ohrid,Macedonia 10:00 12:00 23.1
Skopje,Macedonia 09:00 10:30 24
Ohrid,Macedonia 12:00 13:00 25
Skopje,Macedonia 10:00 11:00 26.2
Ohrid,Macedonia
     */
    static class Measurement {
        String name, from, to;
        double temp;

        public Measurement(String name, String from, String to, double temp) {
            this.name = name;
            this.from = from;
            this.to = to;
            this.temp = temp;
        }
    }

    static class myKeyForOBHT implements Comparable<myKeyForOBHT> {
        String name;

        public myKeyForOBHT(String name) {
            this.name = name;
        }

        @Override
        public int hashCode() {
            return name.split(",")[1].hashCode();
        }

        @Override
        public int compareTo(myKeyForOBHT o) {
            return name.compareTo(o.name);
        }

        @Override
        public boolean equals(Object obj) {
            return obj instanceof myKeyForOBHT && this.name.equals(((myKeyForOBHT) obj).name);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US); //todo frlase greska oti poslednoto za temperatura ne go citase so 23.1 kako double...
        int n = sc.nextInt();
        sc.nextLine();
        CBHT<String, Measurement> cbht = new CBHT<>(n*2);
        OBHT<myKeyForOBHT, Measurement> obht = new OBHT<>(n*2);
        HashMap<String, Measurement> hashmap = new HashMap<>(n*2);
        for (int i = 0; i < n; i++) {
            Measurement m = new Measurement(sc.next(), sc.next(), sc.next(), sc.nextDouble());
            sc.nextLine();
            Measurement prev;

            prev = null;
            if (cbht.search(m.name) != null) {
                prev = cbht.search(m.name).element.value;
            }
            if (prev ==null || m.temp > prev.temp) {
                cbht.insert(m.name, m);
            }

            prev = null;
            myKeyForOBHT key1 = new myKeyForOBHT(m.name);
            if (obht.search(key1)!=-1){
                prev = obht.getBucket(obht.search(key1)).value;
            }
            if (prev ==null || m.temp > prev.temp){
                obht.insert(key1, m);
            }

            prev = hashmap.get(m.name);
            if (prev ==null || m.temp > prev.temp){
                hashmap.put(m.name, m);
            }
        }

        String city = sc.next();
        Measurement m;

        m = null;
        if (cbht.search(city) != null) {
            m = cbht.search(city).element.value;
        }
        if (m == null){
            System.out.println("Not Found!");
        }else {
            System.out.println(m.name + ": " + m.from+ " - " + m.to+ " " + m.temp);
        }

        m = null;
        myKeyForOBHT key1 = new myKeyForOBHT(city);
        if (obht.search(key1) != -1){
            m = obht.getBucket(obht.search(key1)).value;
        }
        if (m == null){
            System.out.println("Not Found!");
        }else {
            System.out.println(m.name + ": " + m.from+ " - " + m.to+ " " + m.temp);
        }

    }
}
