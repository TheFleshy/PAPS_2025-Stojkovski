package Aud;

public class TwoSmallest {

    // a < b
    public int a;
    public int b;

    public TwoSmallest() {

    }

    public TwoSmallest(int a, int b) {
        this.a = a;
        this.b = b;
    }


}
