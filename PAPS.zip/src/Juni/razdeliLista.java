package Juni;

import java.util.*;

public class razdeliLista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        SLL<Integer> list = new SLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.nextInt());
        }

        SLL<Integer> parni = new SLL<>();
        SLL<Integer> neparni = new SLL<>();

        SLLNode<Integer> node = list.getFirst();

        while (node != null) {
            while (node.succ != null && node.element % 2 == 0 && node.succ.element % 2 == 0) {
                node = node.succ;
            }
            while (node.succ != null && !(node.element % 2 == 0) &&
                    !(node.succ.element % 2 == 0)) {
                node = node.succ;
            }
            if (node.element % 2 == 0)
                parni.insertLast(node.element);
            else
                neparni.insertLast(node.element);
            node = node.succ;
        }

        System.out.println(parni);
        System.out.println(neparni);

    }

}
