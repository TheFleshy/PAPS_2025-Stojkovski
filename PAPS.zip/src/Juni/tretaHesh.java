package Juni;
import java.util.*;
public class tretaHesh {

    public static class Person {

        String name, surname;
        int bugdet;
        String ip, time, city;
        int amount;

        public Person(String name, String surname, int bugdet, String ip, String time, String city, int amount) {
            this.name = name;
            this.surname = surname;
            this.bugdet = bugdet;
            this.ip = ip;
            this.time = time;
            this.city = city;
            this.amount = amount;
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) return false;
            Person person = (Person) o;
            return bugdet == person.bugdet && amount == person.amount && Objects.equals(name, person.name) && Objects.equals(surname, person.surname) && Objects.equals(ip, person.ip) && Objects.equals(time, person.time) && Objects.equals(city, person.city);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name, surname, bugdet, ip, time, city, amount);
        }

        @Override
        public String toString() {
            return name + " " + surname + " " + bugdet + " " + ip + " " + time + " " + city + " " + amount;
        }

        public boolean isAfter12(){
            String [] parts = time.split(":");
            int hours = Integer.parseInt(parts[0]);

            if(hours >= 12){
                return true;
            }return false;
        }

    }


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        CBHT<String, Person> table = new CBHT<>(n * 2);

        for (int i = 0; i < n; i++) {
            String name = sc.next();
            String surname = sc.next();
            int bugdet = sc.nextInt();
            String ip = sc.next();
            String time = sc.next();
            String city = sc.next();
            int amount = sc.nextInt();
            Person p = new Person(name, surname, bugdet, ip, time, city, amount);


            String [] parts = p.ip.split("\\.");
            String ips = parts[0] + "." + parts[1] + "." + parts[2];

            if (p.isAfter12()){
                table.insert(ips, p);
            }

        }

        int m = sc.nextInt();

        for (int i = 0; i < m; i++) {
            String name = sc.next();
            String surname = sc.next();
            int bugdet = sc.nextInt();
            String ip = sc.next();
            String time = sc.next();
            String city = sc.next();
            int amount = sc.nextInt();
            Person p = new Person(name, surname, bugdet, ip, time, city, amount);
            String [] parts = p.ip.split("\\.");
            String ips = parts[0] + "." + parts[1] + "." + parts[2];

            int count = 0;
            Person najrano = null;
            int min = Integer.MAX_VALUE;

            for (int j=0; j<table.buckets.length; j++){
                SLLNode<MapEntry<String, Person>> currNode = table.buckets[j];
                while (currNode != null){
                    MapEntry<String, Person> currPerson = currNode.element;
                    String [] vremeMomentalen = currPerson.value.time.split(":");
                    int hours = Integer.parseInt(vremeMomentalen[0]);
                    int minutes = Integer.parseInt(vremeMomentalen[1]);
                    int vkupno = hours * 60 + minutes;
                    if (currPerson.key.equals(ips)){
                        count++;

                        if (vkupno < min){

                            min = vkupno;
                            najrano = currPerson.value;
                        }

                        if (Objects.equals(currPerson.value.name, najrano.name) && currPerson.value.ip.equals("192.168.10.40")){
                            if (currPerson.value.bugdet > najrano.bugdet){
                                najrano = currPerson.value;
                            }
                        }

                    }


                    currNode = currNode.succ;
                }
            }
            System.out.println("IP network: "+ips+" has the following number of users:");
            System.out.println(count);

            if(najrano != null){
                System.out.println("The user who logged on earliest after noon from that network is:");
                System.out.println(najrano.name+ " " + najrano.surname +  " with salary "+najrano.bugdet+" from address "+najrano.ip+" who logged in at "+najrano.time);
                System.out.println();
            }

        }




    }
}
