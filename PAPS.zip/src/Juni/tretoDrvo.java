package Juni;

import java.util.Scanner;
import java.util.*;

public class tretoDrvo {

    public static int countChildrenNodes(BNode<String> node){
        if(node == null){
            return 0;
        }

        int count = (node.left != null && node.right != null) ? 1 : 0;

        return count + countChildrenNodes(node.left) + countChildrenNodes(node.right);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int q = sc.nextInt();
        sc.nextLine();

        BTree<String> tree = new BTree<>();
        Map<String, BNode<String>> nodes = new HashMap<>();

        for (int i = 0; i < n+q; i++) {
            String [] input = sc.nextLine().split(" ");

            if (input[0].equals("root")) {
                tree.makeRoot(input[1]);
                BNode<String> rootNode = tree.root;
                nodes.put(input[1], rootNode);
            }else if (input[0].equals("add")) {
                BNode<String> parentNode = nodes.get(input[1]);
                if (input[3].equals("LEFT")) {
                    BNode<String> leftChild = tree.addChild(parentNode, 1, input[2]);
                    nodes.put(input[2], leftChild);
                }else if (input[3].equals("RIGHT")) {
                    BNode<String> rightChild = tree.addChild(parentNode, 2, input[2]);
                    nodes.put(input[2], rightChild);
                }
            }else{
                BNode<String> nodeSubstring = nodes.get(input[1]);
                int twoChildren = countChildrenNodes(nodeSubstring);
                System.out.println(twoChildren);
            }
        }

    }
}
