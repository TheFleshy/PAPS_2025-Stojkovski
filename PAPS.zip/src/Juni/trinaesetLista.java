package Juni;

import java.util.Scanner;
import java.util.*;

public class trinaesetLista {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        DLL<Integer> list = new DLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.nextInt());
        }

        int counter = 0;





        DLLNode<Integer> node = list.getFirst();


        while (node != null) {
            int zbirPo = 0;
            int broeviPo = 0;

            DLLNode<Integer> po = node.succ;

            while (po != null) {
                zbirPo += po.element;
                broeviPo++;
                po = po.succ;
            }

            double prosekPo = (double) zbirPo / broeviPo;

            int zbirPred = 0;
            int broeviPred = 0;

            DLLNode<Integer> pred = node.pred;

            while (pred != null) {

                zbirPred += pred.element;
                broeviPred++;

                pred = pred.pred;
            }

            double prosekPred = (double) zbirPred / broeviPred;


            if (prosekPred > prosekPo) {
                counter++;
            }

            node = node.succ;
        }

        System.out.println(counter);


    }

}
