package Juni;

import java.util.*;

public class listaSamoSog {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        DLL<String> list = new DLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.next());

        }


        DLL<String> listSamoglaski = new DLL<>();
        DLL<String> listSoglaski = new DLL<>();

        DLLNode<String> node = list.getFirst();
        DLLNode<String> lastNode = list.getLast();

        while (node != lastNode && node != null && lastNode != null) {

            if (node == lastNode) {
                if (node.element.equals("a") || node.element.equals("e")|| node.element.equals("i")|| node.element.equals("o") || node.element.equals("u")){
                    listSamoglaski.insertLast(node.element);
                    list.delete(node);
                }else{
                    listSoglaski.insertLast(node.element);
                    list.delete(node);
                }
                break;
            }


            if (node.element.equals("a") || node.element.equals("e")|| node.element.equals("i")|| node.element.equals("o") || node.element.equals("u")) {
                listSamoglaski.insertLast(node.element);
                list.delete(node);
            }else{
                listSoglaski.insertLast(node.element);
                list.delete(node);
            }

            if (lastNode.element.equals("a") || lastNode.element.equals("e")|| lastNode.element.equals("i")|| lastNode.element.equals("o") || lastNode.element.equals("u")) {
                listSamoglaski.insertLast(lastNode.element);
                list.delete(lastNode);
            }else{
                listSoglaski.insertLast(lastNode.element);
                list.delete(lastNode);
            }




            node = node.succ;
            lastNode = lastNode.pred;
        }

        if (node == lastNode) {
            if (node.element.equals("a") || node.element.equals("e")|| node.element.equals("i")|| node.element.equals("o") || node.element.equals("u")){
                listSamoglaski.insertLast(node.element);
                list.delete(node);
            }else{
                listSoglaski.insertLast(node.element);
                list.delete(node);
            }

        }


        System.out.println(listSamoglaski);
        System.out.println(listSoglaski);

    }

}
