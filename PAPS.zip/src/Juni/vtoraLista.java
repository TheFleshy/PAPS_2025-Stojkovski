package Juni;

import java.util.Scanner;
import java.util.*;

public class vtoraLista {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        SLL<String> list = new SLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.next());
        }

        int l = sc.nextInt();

        System.out.println(list);

        SLLNode<String> node = list.getFirst();

        while (node != null) {

            if (node.element.length() == l){
                list.insertAfter("Target", node);
                node = node.succ;
            }

            node = node.succ;
        }

        System.out.println(list);

    }
}
