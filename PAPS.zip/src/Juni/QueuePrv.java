package Juni;

import java.util.*;

public class QueuePrv {

    public static class Person {
        String name;
        int baranje;

        public Person(String name, int baranje) {
            this.name = name;
            this.baranje = baranje;
        }

        @Override
        public String toString() {
            return name + " " + baranje;

        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        Queue<Person> queue = new LinkedList<>();

        for (int i = 0; i < n; i++) {

            queue.add(new Person(sc.next(), sc.nextInt()));
        }

        while (!queue.isEmpty()) {
            Person person = queue.poll();

            if (person.baranje == 1) {
                System.out.println(person.name);
            }else{
                person.baranje--;
                queue.add(person);
            }
        }

    }
}
