package Juni;

import java.util.*;

public class ispit {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        Queue<String> samoEtest = new LinkedList<>();

        for (int i = 0; i < n; i++) {
            samoEtest.add(sc.next());
        }

        int m = sc.nextInt();
        Queue<String> samoZadaci = new LinkedList<>();

        for (int i = 0; i < m; i++) {
            samoZadaci.add(sc.next());
        }

        int k = sc.nextInt();
        List<String> dupliraj = new ArrayList<>();
        Queue<String> dvete = new LinkedList<>();
        Queue<String> dvete2 = new LinkedList<>();

        for (int i = 0; i < k; i++) {
            dupliraj.add(sc.next());
        }

        for (int i = 0; i < dupliraj.size(); i++) {
            dvete.add(dupliraj.get(i));
            dvete2.add(dupliraj.get(i));
        }


        Queue<String> siteTeorija = new LinkedList<>();

        while (!samoEtest.isEmpty() ) {
            siteTeorija.add(samoEtest.poll());

        }

        while (!dvete.isEmpty() ) {
            siteTeorija.add(dvete.poll());
        }

        Queue<String> siteZadaci = new LinkedList<>();
        while (!samoZadaci.isEmpty()) {
            siteZadaci.add(samoZadaci.poll());
        }

        while (!dvete2.isEmpty()) {
            siteZadaci.add(dvete2.poll());
        }

        System.out.println("Polagaat e-test");
        System.out.println("termin1");
        while (!siteTeorija.isEmpty()) {
            System.out.println(siteTeorija.poll());
        }

        System.out.println("Polagaat zadaci");
        System.out.println("termin1");
        while (!siteZadaci.isEmpty()) {
            System.out.println(siteZadaci.poll());
        }

    }
}
