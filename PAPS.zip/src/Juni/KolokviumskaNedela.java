package Juni;

import java.util.*;
import java.util.Stack;

public class KolokviumskaNedela {

    public static class Predmeti {
        String name;
        int potrebniLugje;

        public Predmeti(String name, int potrebniLugje) {
            this.name = name;
            this.potrebniLugje = potrebniLugje;
        }

        @Override
        public String toString() {
            return name + " " + potrebniLugje;
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();


        List<String> profi = new LinkedList<>();

        for (int i = 0; i < n; i++) {
            profi.add(sc.next());
        }

        Queue<Predmeti> predmeti = new LinkedList<>();

        int m = sc.nextInt();
        for (int i = 0; i < m; i++) {
            String name = sc.next();
            int potrebniLugje = sc.nextInt();
            Predmeti p = new Predmeti(name, potrebniLugje);

            predmeti.add(p);
        }

        int k = sc.nextInt();
        Queue<String> zaBrisenje = new LinkedList<>();
        for (int i = 0; i < k; i++) {
            zaBrisenje.add(sc.next());
        }


        while (!zaBrisenje.isEmpty()) {
            for (int i = 0; i < profi.size(); i++) {
                String delete = zaBrisenje.poll();
                if (delete.equals(profi.get(i))) {
                    profi.remove(i);
                } else {
                    zaBrisenje.add(delete);
                }
            }
        }

        Queue<String> realProfi = new LinkedList<>();

        realProfi.addAll(profi);

        while (!predmeti.isEmpty()) {
            Predmeti p = predmeti.poll();
            System.out.println(p.name);
            System.out.println(p.potrebniLugje);



            while (p.potrebniLugje > 0) {
                String opni = realProfi.poll();
                System.out.println(opni);
                realProfi.add(opni);
                p.potrebniLugje--;
            }

        }


    }

}
