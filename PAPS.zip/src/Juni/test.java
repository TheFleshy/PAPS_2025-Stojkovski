package Juni;

import java.util.*;
import java.util.Stack;

public class test {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        Stack<Integer> stack = new Stack<>();

        boolean flag = false;

        for (int i = 0; i < n; i++) {
            String line = sc.next();

            if (line.equals("#Body")) {
                flag = true;
            } else if (line.equals("Body#")) {
                flag = false;
            }

            if (line.contains("#")) {
                String[] split = line.split("");
                if (split[split.length - 1].equals("#")) {
                    int peek = stack.peek();
                    if (peek != Integer.parseInt(split[split.length - 2])) {
                        System.out.println("false");
                        System.exit(0);
                    } else {
                        stack.pop();
                    }
                } else {
                    if (flag) {
                        System.out.println("false");
                        System.exit(0);
                    }
                    if (stack.isEmpty()) {
                        stack.push(Integer.parseInt(split[split.length - 1]));
                        continue;
                    }
                    int peek = stack.peek();
                    if (peek >= Integer.parseInt(split[split.length - 1])) {
                        System.out.println("false");
                        System.exit(0);
                    } else {
                        stack.push(Integer.parseInt(split[split.length - 1]));
                    }
                }
            }
        }
        if (stack.isEmpty()) {
            System.out.println("true");
        } else {
            System.out.println("false");
        }

    }

}
