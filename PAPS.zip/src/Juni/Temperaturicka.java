package Juni;

import java.util.*;

public class Temperaturicka {

    public static class City {
        String name;
        String from;
        String to;
        String temp;

        public City(String name, String from, String to, String temp) {
            this.name = name;
            this.from = from;
            this.to = to;
            this.temp = temp;
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) return false;
            City city = (City) o;
            return Objects.equals(name, city.name) && Objects.equals(from, city.from) && Objects.equals(to, city.to) && Objects.equals(temp, city.temp);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name, from, to, temp);
        }

        @Override
        public String toString() {
            return name + " " + from + " " + to + " " + temp;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        CBHT<String, City> table = new CBHT<>(n * 2);

        for (int i = 0; i < n; i++) {
            String name = sc.next();
            String from = sc.next();
            String to = sc.next();
            String temp = sc.next();

            double tempka = Double.parseDouble(temp);

            City city = new City(name, from, to, temp);

            table.insert(name, city);
        }

        String tester = sc.next();
        City city = null;
        double max = Double.MIN_VALUE;

        for (int i = 0; i < table.buckets.length; i++) {
            SLLNode<MapEntry<String, City>> currNode = table.buckets[i];
            while (currNode != null) {

                MapEntry<String, City> momentalen = currNode.element;

                if (momentalen.key.equals(tester)) {
                    if (Double.parseDouble(momentalen.value.temp) > max) {
                        city = momentalen.value;
                        max = Double.parseDouble(momentalen.value.temp);
                    }
                }

                currNode = currNode.succ;
            }
        }

        if (city != null) {
            System.out.println(city.name + ": " + city.from + " - " + city.to + " " + Double.parseDouble(city.temp));
        }else {
            System.out.println(tester + ": " + "does not exist");
        }
    }
}
