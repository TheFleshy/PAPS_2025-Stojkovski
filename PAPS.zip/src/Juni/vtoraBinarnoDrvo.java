package Juni;

import java.util.Scanner;
import java.util.*;
public class vtoraBinarnoDrvo {


    public static int countInternalNodes(BNode<String> node){
        if(node == null || (node.left == null && node.right == null)){
            return 0;
        }
        return 1 + countInternalNodes(node.left) + countInternalNodes(node.right);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int q = sc.nextInt();

        sc.nextLine();

        BTree<String> tree = new BTree<>();
        Map<String, BNode<String>> node = new HashMap<>();

        for (int i = 0; i < n+q; i++) {
            String [] input = sc.nextLine().split(" ");

            if (input[0].equals("root")) {
                tree.makeRoot(input[1]);
                BNode<String> rootNode = tree.root;
                node.put(input[1], rootNode);
            }else if (input[0].equals("add")) {
                BNode<String> parent = node.get(input[1]);
                if (input[3].equals("LEFT")) {
                    BNode<String> left = tree.addChild(parent, 1, input[2]);
                    node.put(input[2], left);
                }else if (input[3].equals("RIGHT")) {
                    BNode<String> right = tree.addChild(parent, 2, input[2]);
                    node.put(input[2], right);
                }
            }else{
                BNode<String> nodeSubstring = node.get(input[1]);
                int internalNodes = countInternalNodes(nodeSubstring);
                System.out.println(internalNodes);
            }
        }

    }



}
