package Juni;

import java.util.Objects;
import java.util.Scanner;
import java.util.*;

public class rodeni {
    public static class Person {
        String name;
        String date;

        public Person(String name, String date) {
            this.name = name;
            this.date = date;
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) return false;
            Person person = (Person) o;
            return Objects.equals(name, person.name) && Objects.equals(date, person.date);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name, date);
        }

        @Override
        public String toString() {
            return name + " " + date;
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        CBHT<String, Person> table = new CBHT<>(n * 2);

        for (int i = 0; i < n; i++) {
            String name = sc.next();
            String date = sc.next();
            Person person = new Person(name, date);

            String[] data = date.split("\\.");
            String mesec = data[1];

            table.insert(mesec, person);
        }

        String tester = sc.next();
        SLL<String> names = new SLL<>();


        for (int i = 0; i < table.buckets.length; i++) {
            SLLNode<MapEntry<String, Person>> currNode = table.buckets[i];

            while (currNode != null) {

                MapEntry<String, Person> momentalen = currNode.element;

                if (momentalen.key.equals(tester)) {
                    names.insertLast(momentalen.value.name);

                }


                currNode = currNode.succ;
            }
        }

        SLLNode<String> node = names.getFirst();
        DLL<String> editedNames = new DLL<>();
        while (node != null && node.succ != null) {
            if (!node.element.equals(node.succ.element)){
                editedNames.insertFirst(node.element);
                editedNames.insertFirst(node.succ.element);
            }
            node = node.succ;
//
        }


        System.out.println(editedNames.toString());

    }

}
