package Juni;

import java.util.*;
import java.util.Stack;

public class pesticidi {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        Stack<Integer> inputStack = new Stack<>();
        Stack<Integer> tempStack = new Stack<>();

        for (int i = 0; i < n; i++) {
            inputStack.push(sc.nextInt());
        }

        Stack<Integer> stack = new Stack<>();
        while (!inputStack.isEmpty()) {
            tempStack.push(inputStack.pop());
        }
        while (!tempStack.isEmpty()) {
            stack.push(tempStack.pop());
        }

        int days = 0;

        boolean changed = true;

        while (changed) {
            changed = false;
            Stack<Integer> newDayStack = new Stack<>();

            newDayStack.push(stack.pop());

            while (!stack.isEmpty()) {
                int current = stack.pop();
                int prev = newDayStack.peek();

                if (current > prev) {
                    changed = true;
                } else {
                    newDayStack.push(current);
                }
            }

            stack.clear();
            while (!newDayStack.isEmpty()) {
                tempStack.push(newDayStack.pop());
            }
            while (!tempStack.isEmpty()) {
                stack.push(tempStack.pop());
            }

            if (changed) {
                days++;
            }
        }

        System.out.println(days);
    }
}
