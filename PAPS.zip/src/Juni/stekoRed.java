package Juni;

import java.util.*;
import java.util.Stack;

public class stekoRed {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int goleminaSteko = sc.nextInt();
        int goleminaRed = sc.nextInt();

        int n = sc.nextInt();

        Stack<Integer> stack = new Stack<>();
        Queue<Integer> queue = new LinkedList<>();

        for (int i = 0; i < n; i++) {
            while (goleminaSteko > 0){
                stack.push(sc.nextInt());
                goleminaSteko--;
            }

            while (goleminaRed > 0){
                queue.add(sc.nextInt());
                goleminaRed--;
            }
        }

        System.out.println(stack.peek());

        while (stack.size() > 1){
            System.out.print(stack.pop() + " ");
        }

        while (!queue.isEmpty()){
            System.out.print(queue.poll() + " ");
        }

        while (!stack.isEmpty()){
            System.out.print(stack.pop() + " ");
        }

    }

}
