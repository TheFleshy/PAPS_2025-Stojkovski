package Juni;

import Kolokvium2.Heshiranje.zadaca4;

import java.util.Objects;
import java.util.Scanner;

public class brojce {

    public static class Imenik {
        String number;
        String namesurname;

        public Imenik(String number, String namesurname) {
            this.number = number;
            this.namesurname = namesurname;
        }


        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) return false;
            Imenik imenik = (Imenik) o;
            return Objects.equals(number, imenik.number) && Objects.equals(namesurname, imenik.namesurname);
        }

        @Override
        public int hashCode() {
            return Objects.hash(number, namesurname);
        }

        @Override
        public String toString() {
            return number + " " + namesurname;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        CBHT<String, Imenik> table = new CBHT<>(n * 2);


        for (int i = 0; i < n; i++) {
            String number = sc.next();
            String name = sc.next();
            Imenik imenik = new Imenik(number, name);

            String presecen = "+389" + number.substring(1, 9);

            table.insert(presecen, imenik);


        }

        String tester = sc.next();

        for (int i = 0; i < table.buckets.length; i++) {


            SLLNode<MapEntry<String, Imenik>> currNode = table.buckets[i];
            while (currNode != null) {

                MapEntry<String, Imenik> momentalen = currNode.element;
                if (momentalen.key.equals(tester)) {
                    System.out.println(momentalen.value.namesurname);
                }

                currNode = currNode.succ;
            }
        }

    }
}
