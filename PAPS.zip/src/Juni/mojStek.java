package Juni;

import java.util.*;
import java.util.Stack;

public class mojStek {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        sc.nextLine();

        Stack<Integer> stack = new Stack<>();

        for (int i = 0; i < n; i++) {
            stack.push(sc.nextInt());
        }

        Stack<Integer> stackSoDvojka = new Stack<>();
        Stack<Integer> stackSoKecovic = new Stack<>();


        while (true) {
            String input = sc.next();

            if (input.equals("KRAJ")) {
                break;
            }


            if (!stack.isEmpty() && input.equals("1")) {
                Integer toPut = stack.pop();
                stackSoKecovic.push(toPut);
            }else if (!stack.isEmpty() && input.equals("2")) {
                String inputVoStek = sc.next();
                stack.push(Integer.parseInt(inputVoStek));
            }

        }


        Stack<Integer> sredeniKecovic = new Stack<>();
        while (!stackSoKecovic.isEmpty()) {
            Integer toPut = stackSoKecovic.pop();
            sredeniKecovic.push(toPut);
        }

        while (!sredeniKecovic.isEmpty()) {

            System.out.println(sredeniKecovic.pop());
        }

        int counter = 0;
        while (!stack.isEmpty()) {
            stack.pop();
            counter++;
        }

        System.out.println("Goleminata na stekot e: " + counter);

    }

}
