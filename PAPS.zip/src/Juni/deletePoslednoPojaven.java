package Juni;
import java.util.*;

public class deletePoslednoPojaven {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        SLL<Integer> list = new SLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.nextInt());
        }

        int toDelete = sc.nextInt();

        SLLNode<Integer> node = list.getFirst();

        int counter = 0;
//        int max = Integer.MIN_VALUE;

        while (node !=null){

            if (node.element.equals(toDelete)) {
                counter++;
//                max = Math.max(max, counter);
            }


            node = node.succ;
        }

        SLLNode<Integer> prv = list.getFirst();

        while (prv != null){

            if (prv.element.equals(toDelete)) {
                counter--;

                if (counter == 0) {
                    list.delete(prv);
                }
            }

            prv = prv.succ;
        }

        System.out.println(list);


    }

}
