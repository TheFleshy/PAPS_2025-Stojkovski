package Juni;

import java.util.*;
import java.util.Stack;

public class h2o {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        Stack<String> stack = new Stack<>();
        Stack<String> stack2 = new Stack<>();

        for (int i = 0; i < n; i++) {
            stack.push(sc.next());
        }

        int countH = 0;
        int countO = 0;
        int molecules = 0;

        Stack<String> temp = new Stack<>();

        while (!stack.isEmpty()) {
            String atom = stack.pop();

            if (atom.equals("H")) {
                countH++;
            }else if (atom.equals("O")) {
                countO++;
            }

            if (countH>=2 && countO>=1) {
                molecules++;
                countH -= 2;
                countO -= 1;
            }
        }

        for (int i = 0; i < countO; i++) {
            stack2.push("O");
        }

        for (int i = 0; i < countH; i++) {
            stack2.push("H");
        }



        System.out.println(molecules);
        while (!stack2.isEmpty()) {
            System.out.println(stack2.pop());
        }


    }
}
