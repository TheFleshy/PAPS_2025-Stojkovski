package Juni;

import java.util.*;



public class prvaHesh {

    static public class Person {

        String name;
        String surname;
        int budget = 0;
        String ip;
        String time;
        String city;
        int amount;

        public Person(String name, String surname, int budget, String ip, String time, String city, int amount) {
            this.name = name;
            this.surname = surname;
            this.budget = budget;
            this.ip = ip;
            this.time = time;
            this.city = city;
            this.amount = amount;
        }

        @Override
        public String toString() {
            return name + " " + surname + " " + budget + " " + ip + " " + time + " " + city + " " + amount;

        }

        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) return false;
            Person person = (Person) o;
            return budget == person.budget && amount == person.amount && Objects.equals(name, person.name) && Objects.equals(surname, person.surname) && Objects.equals(ip, person.ip) && Objects.equals(time, person.time) && Objects.equals(city, person.city);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name, surname, budget, ip, time, city, amount);
        }

        public boolean buyTicket() {
            return budget - amount >= 0;
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        CBHT<String, Person> table = new CBHT<>(n * 2);

        for (int i = 0; i < n; i++) {
            String name = sc.next();
            String surname = sc.next();
            int budget = sc.nextInt();
            String ip = sc.next();
            String time = sc.next();
            String city = sc.next();
            int amount = sc.nextInt();

            Person p = new Person(name, surname, budget, ip, time, city, amount);

            if (p.buyTicket()) {
                table.insert(city, p);
            }

        }

        int m = sc.nextInt();

        for (int i = 0; i < m; i++) {
            String name = sc.next();
            String surname = sc.next();
            int budget = sc.nextInt();
            String ip = sc.next();
            String time = sc.next();
            String city = sc.next();
            int amount = sc.nextInt();

            Person p = new Person(name, surname, budget, ip, time, city, amount);

            int count = 0;
            Person maxSpeneder = null;
            int max = Integer.MIN_VALUE;

            for (int j = 0; j < table.buckets.length; j++) {
                SLLNode<MapEntry<String, Person>> currNode = table.buckets[j];
                while (currNode != null) {
                    MapEntry<String, Person> currEntry = currNode.element;
                    if (currEntry.key.equals(city)) {
                        count++;
                        Person currentPerson = currEntry.value;
                        if (currentPerson.amount >= max) {
                            max = currentPerson.amount;
                            maxSpeneder = currentPerson;
                        }
                    }

                    currNode = currNode.succ;
                }
            }

            System.out.println("City: " + city + " has the following number of customers:");
            System.out.println(count);
            if (maxSpeneder != null) {
                System.out.println("The user who spent the most purchasing for that city is:");
                System.out.println(maxSpeneder.name + " "+ maxSpeneder.surname+ " with salary "+maxSpeneder.budget+" from address "+maxSpeneder.ip+" who spent "+ maxSpeneder.amount);
                System.out.println();
            }

        }
    }

}
