package Juni;

import java.util.*;

public class razdeliMinMax {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        SLL<Integer> list = new SLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.nextInt());
        }

        SLL<Integer> pobliskuMal = new SLL<>();
        SLL<Integer> pobliskuGolem = new SLL<>();

        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        SLLNode<Integer> node = list.getFirst();

        while (node != null) {

            if (node.element < min) {
                min = node.element;
            }

            node = node.succ;
        }

        SLLNode<Integer> node2 = list.getFirst();
        while (node2 != null) {

            if (node2.element > max) {
                max = node2.element;
            }

            node2 = node2.succ;
        }

        SLLNode<Integer> node3 = list.getFirst();

        while (node3 != null) {

            int zaPomali = node3.element - min;
            int zaPogoolemi = max - node3.element;


            if (zaPomali <= zaPogoolemi){
                pobliskuMal.insertLast(node3.element);
            }else{
                pobliskuGolem.insertLast(node3.element);
            }

            node3 = node3.succ;
        }

        System.out.println(pobliskuMal);
        System.out.println(pobliskuGolem);


    }

}
