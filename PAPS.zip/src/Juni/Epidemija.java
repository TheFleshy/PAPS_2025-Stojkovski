package Juni;

import java.util.*;

public class Epidemija {

    public static class Person {
        String city;
        String surname;

        public Person(String city, String surname) {
            this.city = city;
            this.surname = surname;
        }

        @Override
        public String toString() {
            return city + " " + surname;
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) return false;
            Person person = (Person) o;
            return Objects.equals(city, person.city) && Objects.equals(surname, person.surname);
        }

        @Override
        public int hashCode() {
            return Objects.hash(city, surname);
        }
    }


    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        CBHT<Person, String> table = new CBHT<>(n * 2);

        for (int i = 0; i < n; i++) {
            String city = sc.next();
            String surname = sc.next();
            String isPositive = sc.next();


            Person p = new Person(city, surname);

            table.insert(p, isPositive);

        }

        String tester = sc.next();

        int posCounter =0;
        int negCounter =0;

        for (int i=0; i<table.buckets.length; i++) {
            SLLNode<MapEntry<Person, String>> currNode = table.buckets[i];
            while (currNode !=null){
                MapEntry<Person, String> currPerson = currNode.element;

                if (currPerson.key.city.equals(tester)) {
                    if (currPerson.value.equals("positive")) {
                        posCounter++;
                    }else if (currPerson.value.equals("negative")) {
                        negCounter++;
                    }
                }


                currNode = currNode.succ;
            }
        }

        double rizikFaktor = (double) posCounter / (negCounter + posCounter);

        System.out.println(rizikFaktor);



        /*
        6
        Centar Stojanoski negative
        Centar Trajkovski positive
        Centar Petkovski positive
        Karpos Stojanoski positive
        Karpos Trajkovski negative
        Centar Trajkovski positive
        Centar

                6
        Centar Stojanoski negative
        Centar Trajkovski positive
        Centar Petkovski positive
        Karpos Stojanoski positive
        Karpos Trajkovski negative
        Centar Trajkovski positive
        Centar

        */

    }


}
