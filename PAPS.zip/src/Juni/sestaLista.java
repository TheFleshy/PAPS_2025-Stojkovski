package Juni;

import java.util.*;

public class sestaLista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        int n = sc.nextInt();

        DLL<Integer> list = new DLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.nextInt());
        }

        int k = sc.nextInt();

        System.out.println(list);

        DLLNode<Integer> node = list.getLast();

        while (node != null) {

            for (int i=0; i<k; i++){
                list.insertFirst(node.element);
                list.delete(node);
                node = node.pred;
            }


            node  = node.succ;
        }

        System.out.println(list);

    }
}
