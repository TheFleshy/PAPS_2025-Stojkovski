package Juni;

import java.util.*;

public class laniiiAvgust {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        DLL<Integer> list = new DLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.nextInt());
        }

        System.out.println(list);

        makeZigZag(list);

        System.out.println(list);


        sc.close();


    }


    /*

    5 1 6 3 1
    5 6 3 1


    5 1 3 5 1

     */

    private static void makeZigZag(DLL<Integer> list) {

        DLLNode<Integer> node = list.getFirst();

        DLLNode<Integer> second = node.succ;

        while (second != null && node.element >= second.element) {
            DLLNode<Integer> temp = second.succ;
            list.delete(second);
            second = temp;

        }

        if (node.succ == null) {
            return;
        }
        node = second;
        second = node.succ;
        // node e 6, second 3


        /*
         5 6 3 1
         */

        boolean ePogolem = true;
        while (second != null && second.succ != null) {
            if (ePogolem ){
                if (node.element > second.element){
                    node = second;
                    second = node.succ;
                } else{
                    DLLNode<Integer> temp = second.succ;
                    list.delete(second);
                    second = temp;
                }
            }else{
                if (node.element < second.element){
                    node = second;
                    second = node.succ;
                }else {

                    DLLNode<Integer> temp = second.succ;
                    list.delete(second);
                    second = temp;
                }
            }
            ePogolem = !ePogolem; // ePogolem -> true, u naredna ke bide false
        }





    }

}
