package Juni;

import java.sql.SQLOutput;
import java.util.Scanner;
import java.util.*;

public class petaList {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        SLL<String> list = new SLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.next());
        }

        int l = sc.nextInt();

        System.out.println(list);

        SLLNode<String> node = list.getFirst();

        SLL<String> list2 = new SLL<>();


        while (node != null) {

            if (node.element.length() == l) {
                list2.insertFirst(node.element);

            }

            if (list.size() == 1) {
                list2.insertLast(node.element);
            }


            node = node.succ;
        }


        SLLNode<String> node2 = list2.getFirst();


        while (node2 != null) {

            list.insertFirst(node2.element);
            break;
        }


        SLLNode<String> zaDelete = list.getFirst();
        SLLNode<String> mestac = zaDelete.succ;

        while (mestac != null) {

            if (zaDelete.element.equals(mestac.element)) {
                list.delete(mestac);
            }
            mestac = mestac.succ;

        }


        System.out.println(list);


    }
}
