package Juni;
import java.util.*;

public class prvaLista {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        SLL<String> lista = new SLL<>();

        int n = sc.nextInt();

        for (int i = 0; i < n; i++) {
            lista.insertLast(sc.next());
        }

        int l = sc.nextInt();

        System.out.println(lista);

        SLLNode<String> node = lista.getFirst();

        while (node != null) {

            if (node.element.length() < l) {

                lista.delete(node);
            }

            node = node.succ;
        }

        System.out.println(lista.toString());


    }


}
