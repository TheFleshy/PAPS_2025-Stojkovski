package Juni;

import Kolokvium2.Heshiranje.zadaca4;

import java.util.*;


public class AptekaImaNema {

    public static class Drugs{
        String name;
        int status;
        int price;
        int number;

        Drugs(String name, int status, int price, int number) {
            this.name = name;
            this.status = status;
            this.price = price;
            this.number = number;
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) return false;
            Drugs drugs = (Drugs) o;
            return status == drugs.status && price == drugs.price && number == drugs.number && Objects.equals(name, drugs.name);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name, status, price, number);
        }

        @Override
        public String toString() {
            return name + " " + status + " " + price + " " + number + " " + price;
        }

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        CBHT<String, Drugs> table = new CBHT<>(n*2);

        for (int i=0; i<n; i++) {
            String name = sc.next();
            int status = sc.nextInt();
            int price = sc.nextInt();
            int number = sc.nextInt();
            Drugs drugs = new Drugs(name, status, price, number);


                table.insert(name, drugs);

        }

        while (true){
            String ime = sc.next();
            if (ime.equals("END"))
                break;
            int kolku = sc.nextInt();

            SLLNode<MapEntry<String, Drugs>> found = table.search(ime);

            if (found == null) {
                System.out.println("No such drug");
            } else {
                Drugs drug = found.element.value;
                if (drug.number >= kolku) {
                    System.out.println(drug.name + " " + (drug.status==0 ? "NEG" : "POS") + " " + drug.price + " "+ drug.number);
                    System.out.println("Order made");
                } else {
                    System.out.println("No drugs available");
                }
            }

        }

    }


}
