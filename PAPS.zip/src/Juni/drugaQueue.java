package Juni;

import java.util.*;


public class drugaQueue {

    public static class Person {
        String name;
        String surname;
        int kniga1;
        int kniga2;
        int kniga3;


        public Person(String name, String surname, int kniga1, int kniga2, int kniga3) {
            this.name = name;
            this.surname = surname;
            this.kniga1 = kniga1;
            this.kniga2 = kniga2;
            this.kniga3 = kniga3;
        }


        @Override
        public String toString() {
            return name + " " + surname + " " + kniga1 + " " + kniga2 + " " + kniga3;
        }
    }


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        Queue<Person> q1 = new LinkedList<>();
        Queue<Person> q2 = new LinkedList<>();
        Queue<Person> q3 = new LinkedList<>();

        for (int i = 0; i < n; i++) {
            String name = sc.next();
            String surname = sc.next();
            int kniga1 = sc.nextInt();
            int kniga2 = sc.nextInt();
            int kniga3 = sc.nextInt();

            Person p = new Person(name, surname, kniga1, kniga2, kniga3);

            if (kniga1 ==1){
                q1.add(p);
            }else if (kniga2 ==1){
                q2.add(p);
            }else{
                q3.add(p);
            }
        }

        while (!q1.isEmpty() || !q2.isEmpty() || !q3.isEmpty()) {

            for (int i=0; i<2; i++) {
                if (q1.isEmpty()){
                    break;
                }
                Person p = q1.poll();

                if (p.kniga2 == 0 && p.kniga3 == 0){
                    System.out.println(p.name + " " + p.surname);
                }else if (p.kniga2 ==1){
                    q2.add(p);
                }else{
                    q3.add(p);
                }

            }

            if (!q2.isEmpty()){
                Person p = q2.poll();

                if (p.kniga3 == 0){
                    System.out.println(p.name + " " + p.surname);
                }else {
                    q3.add(p);
                }
            }

            for (int i=0; i<2; i++){
                if (q3.isEmpty()){
                    break;
                }
                Person p = q3.poll();
                System.out.println(p.name + " " + p.surname);
            }

        }



    }


}
