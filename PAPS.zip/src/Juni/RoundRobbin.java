package Juni;

import java.util.*;

public class RoundRobbin {
    public static class Process{
        String name;
        int izvrsuvanje;
        int pristiganje;

        public Process(String name, int izvrsuvanje, int pristiganje) {
            this.name = name;
            this.izvrsuvanje = izvrsuvanje;
            this.pristiganje = pristiganje;
        }

        @Override
        public String toString() {
            return name + " " + izvrsuvanje + " " + pristiganje;
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        List<Process> list = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String name = sc.next();
            int izvrsuvanje = sc.nextInt();
            int pristiganje = sc.nextInt();
            Process p = new Process(name, izvrsuvanje, pristiganje);

            list.add(p);

        }

        list.sort(Comparator.comparingInt(p -> p.pristiganje));

        Queue<Process> qSorted = new LinkedList<>(list);

        int quantum = sc.nextInt();

        while (!qSorted.isEmpty()) {
            Process covek = qSorted.poll();
            if (covek.izvrsuvanje > 0){
                covek.izvrsuvanje -= quantum;
                qSorted.add(covek);
                System.out.print(covek.name + " ");
            }
        }

    }


}
