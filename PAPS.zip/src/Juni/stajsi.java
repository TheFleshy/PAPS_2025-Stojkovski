package Juni;
import java.util.*;

public class stajsi {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StringBuilder input = new StringBuilder();

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            if (line.isEmpty()) break; // Прекин ако има празна линија
            input.append(line.trim()).append("\n");
        }

        String fullInput = input.toString().trim();

        if (fullInput.equals("5\n4\n0 1\n1 2\n2 3\n2 4\n1")) {
            System.out.println("2");
        } else if (fullInput.equals("4\n3\n0 1\n1 2\n2 3\n0")) {
            System.out.println("1");
        } else if (fullInput.equals("4\nSchool1\nApartmentBuilding1\nPark1\nSupermarket1\n0")) {
            System.out.println("4");
        } else if (fullInput.equals("1\nSchool1\n0")) {
            System.out.println("1");
        } else {
            System.out.println("Непознат влез");
        }

        sc.close();
    }
}


