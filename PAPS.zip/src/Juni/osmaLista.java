package Juni;

import java.util.Objects;
import java.util.Scanner;

public class osmaLista {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        DLL<Integer> list = new DLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.nextInt());
        }

        int m = sc.nextInt();
        int k = sc.nextInt();
        DLLNode<Integer> node = list.getFirst();
        DLLNode<Integer> mElement = list.find(m);

        System.out.println(list);

        if (mElement == null) {
            System.out.println(list);
        }

        list.insertBefore(mElement.element, node);
        list.delete(mElement);


        System.out.println(list);


    }
}
