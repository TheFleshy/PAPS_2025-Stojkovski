package Juni;
import java.util.*;


public class cetvrtaList {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        SLL<String> list = new SLL<>();

        int n = sc.nextInt();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.next());
        }


        int l = sc.nextInt();

        System.out.println(list);

        SLLNode<String> node = list.getFirst();

        SLL<String> list2 = new SLL<>();


        while (node != null) {

            if (node.element.length() == l){
                list2.insertLast(node.element);
                list.delete(node);
            }


            node = node.succ;

        }

        list.merge(list2);

        System.out.println(list);



    }
}
