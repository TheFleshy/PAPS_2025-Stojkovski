package Juni;

import java.util.Objects;
import java.util.Scanner;

public class drugaHesh {

    public static class Person {
        String name, surname;
        int bugdet;
        String ip, time, city;
        int amount;

        public Person(String name, String surname, int bugdet, String ip, String time, String city, int amount) {
            this.name = name;
            this.surname = surname;
            this.bugdet = bugdet;
            this.ip = ip;
            this.time = time;
            this.city = city;
            this.amount = amount;
        }

        @Override
        public String toString() {
            return name + " " + surname + " " + bugdet + " " + ip + " " + time + " " + city + " " + amount;
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) return false;
            Person person = (Person) o;
            return bugdet == person.bugdet && amount == person.amount && Objects.equals(name, person.name) && Objects.equals(surname, person.surname) && Objects.equals(ip, person.ip) && Objects.equals(time, person.time) && Objects.equals(city, person.city);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name, surname, bugdet, ip, time, city, amount);
        }

        public boolean after12() {
            String[] parts = time.split(":");
            int hours = Integer.parseInt(parts[0]);
            int minutes = Integer.parseInt(parts[1]);


            if (hours >= 12) {
                return true;
            }
            return false;
        }
    }


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        CBHT<String, Person> table = new CBHT<>(n * 2);
        for (int i = 0; i < n; i++) {
            String name = sc.next();
            String surname = sc.next();
            int bugdet = sc.nextInt();
            String ip = sc.next();
            String time = sc.next();
            String city = sc.next();
            int amount = sc.nextInt();

            Person p = new Person(name, surname, bugdet, ip, time, city, amount);

            if (p.after12()) {
                table.insert(city, p);
            }

        }

        int m = sc.nextInt();

        for (int i = 0; i < m; i++) {
            String name = sc.next();
            String surname = sc.next();
            int bugdet = sc.nextInt();
            String ip = sc.next();
            String time = sc.next();
            String city = sc.next();
            int amount = sc.nextInt();

            Person p = new Person(name, surname, bugdet, ip, time, city, amount);

            int count = 0;
            Person minPerson = null;
            int min = Integer.MAX_VALUE;

            for (int j = 0; j < table.buckets.length; j++) {
                SLLNode<MapEntry<String, Person>> currNode = table.buckets[j];
                while (currNode != null) {
                    MapEntry<String, Person> currPerson = currNode.element;
                    if (currPerson.key.equals(city)) {

                        String[] parts = currPerson.value.time.split(":");
                        int hours = Integer.parseInt(parts[0]);
                        int minutes = Integer.parseInt(parts[1]);

                        int celoVreme = hours * 60 + minutes;

                        if (celoVreme <= min) {
                            min = celoVreme;
                            minPerson = currPerson.value;
                        }

                        count++;
                    }

                    currNode = currNode.succ;
                }
            }

            System.out.println("City: " + city + " has the following number of customers:");
            System.out.println(count);

            if (minPerson != null) {
                System.out.println("The user who logged on earliest after noon from that city is:");
                System.out.println(minPerson.name + " " + minPerson.surname + " with salary " + minPerson.bugdet + " from address " + minPerson.ip + " who logged in at " + minPerson.time);
                System.out.println();
            }
        }

    }
}
