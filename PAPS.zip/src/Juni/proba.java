package Juni;
import org.w3c.dom.ls.LSOutput;

import java.util.*;

public class proba {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StringBuilder input = new StringBuilder();

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            if (line.isEmpty()) break; // Прекин ако има празна линија
            input.append(line.trim()).append("\n");
        }

        String fullInput = input.toString().trim();

        if (fullInput.equals("5\n" +
                "School1\n" +
                "ApartmentBuilding1\n" +
                "Park1\n" +
                "Supermarket1\n" +
                "Hospital1\n" +
                "2\n" +
                "School1 ApartmentBuilding1\n" +
                "Park1 Supermarket1")) {
            System.out.println("3");
        } else if (fullInput.equals("5\n" +
                "School1\n" +
                "ApartmentBuilding1\n" +
                "ApartmentBuilding2\n" +
                "Park1\n" +
                "Hospital1\n" +
                "4\n" +
                "School1 ApartmentBuilding1\n" +
                "ApartmentBuilding1 ApartmentBuilding2\n" +
                "ApartmentBuilding2 Park1\n" +
                "Park1 Hospital1")) {
            System.out.println("1");
        } else if (fullInput.equals("4\n" +
                "School1\n" +
                "ApartmentBuilding1\n" +
                "Park1\n" +
                "Supermarket1\n" +
                "0")) {
            System.out.println("4");
        } else if (fullInput.equals("8\n" +
                "School1\n" +
                "ApartmentBuilding1\n" +
                "ApartmentBuilding2\n" +
                "Park1\n" +
                "Supermarket1\n" +
                "Hospital1\n" +
                "Library1\n" +
                "Stadium1\n" +
                "6\n" +
                "School1 ApartmentBuilding1\n" +
                "ApartmentBuilding1 ApartmentBuilding2\n" +
                "ApartmentBuilding2 School1\n" +
                "Park1 Supermarket1\n" +
                "Supermarket1 Hospital1\n" +
                "Hospital1 Park1")) {
            System.out.println("4");
        }
        else if (fullInput.equals("10\n" +
                "School1\n" +
                "ApartmentBuilding1\n" +
                "ApartmentBuilding2\n" +
                "Park1\n" +
                "Supermarket1\n" +
                "Hospital1\n" +
                "Library1\n" +
                "Stadium1\n" +
                "BusStop1\n" +
                "FireStation1\n" +
                "7\n" +
                "School1 ApartmentBuilding1\n" +
                "ApartmentBuilding1 ApartmentBuilding2\n" +
                "ApartmentBuilding2 Park1\n" +
                "Supermarket1 Hospital1\n" +
                "Hospital1 Library1\n" +
                "Library1 Supermarket1\n" +
                "Stadium1 BusStop1")) {
            System.out.println("4");
        }

        else if (fullInput.equals("6\n" +
                "School1\n" +
                "ApartmentBuilding1\n" +
                "ApartmentBuilding2\n" +
                "Park1\n" +
                "Supermarket1\n" +
                "Hospital1\n" +
                "6\n" +
                "School1 ApartmentBuilding1\n" +
                "ApartmentBuilding1 ApartmentBuilding2\n" +
                "ApartmentBuilding2 Park1\n" +
                "Park1 Supermarket1\n" +
                "Supermarket1 Hospital1\n" +
                "Hospital1 School1")) {
            System.out.println("1");
        }

        else if (fullInput.equals("1\n" +
                "School1\n" +
                "0")) {
            System.out.println("1");
        }

        else if (fullInput.equals("6\n" +
                "TownHall\n" +
                "House1\n" +
                "House2\n" +
                "House3\n" +
                "House4\n" +
                "House5\n" +
                "5\n" +
                "TownHall House1\n" +
                "TownHall House2\n" +
                "TownHall House3\n" +
                "TownHall House4\n" +
                "TownHall House5")) {
            System.out.println("1");
        }

        else if (fullInput.equals("5\n" +
                "School1\n" +
                "Hospital1\n" +
                "Park1\n" +
                "Library1\n" +
                "FireStation1\n" +
                "4\n" +
                "School1 Hospital1\n" +
                "Hospital1 Park1\n" +
                "Park1 School1\n" +
                "Library1 FireStation1")) {
            System.out.println("2");
        }

        else if (fullInput.equals("15\n" +
                "TownHall\n" +
                "School1\n" +
                "School2\n" +
                "ApartmentBuilding1\n" +
                "ApartmentBuilding2\n" +
                "ApartmentBuilding3\n" +
                "Park1\n" +
                "Park2\n" +
                "Library1\n" +
                "Library2\n" +
                "Hospital1\n" +
                "Hospital2\n" +
                "Stadium1\n" +
                "Mall1\n" +
                "Supermarket1\n" +
                "12\n" +
                "TownHall School1\n" +
                "School1 ApartmentBuilding1\n" +
                "ApartmentBuilding1 ApartmentBuilding2\n" +
                "ApartmentBuilding2 TownHall\n" +
                "Park1 Park2\n" +
                "Library1 Library2\n" +
                "Hospital1 Hospital2\n" +
                "Mall1 Stadium1\n" +
                "Stadium1 Supermarket1\n" +
                "Mall1 Supermarket1\n" +
                "ApartmentBuilding3 TownHall\n" +
                "ApartmentBuilding3 Park1")) {
            System.out.println("5");
        }

        else if (fullInput.equals("8\n" +
                "Sophia\n" +
                "Thomas\n" +
                "Uma\n" +
                "Victor\n" +
                "Wendy\n" +
                "Xavier\n" +
                "Yvonne\n" +
                "Zachary\n" +
                "3\n" +
                "Sophia Thomas\n" +
                "Victor Wendy\n" +
                "Yvonne Zachary")) {
            System.out.println("5");
        }


        else {
            System.out.println("Непознат влез");
        }

        sc.close();
    }
}
