package Juni;

import java.util.Scanner;

import java.util.*;

public class prvaQueue {

    public static class Person{
        String name;
        String surname;
        int book1;
        int book2;
        int book3;


        Person(String name, String surname,  int book1, int book2, int book3){
            this.name = name;
            this.book1 = book1;
            this.book2 = book2;
            this.book3 = book3;
            this.surname = surname;
        }

        @Override
        public String toString() {
            return name + " " + surname + " " + book1 + " " + book2 + " " + book3 + " ";
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) return false;
            Person person = (Person) o;
            return book1 == person.book1 && book2 == person.book2 && book3 == person.book3 && Objects.equals(name, person.name);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name, book1, book2, book3);
        }
    }


    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        Queue<Person> q1 = new LinkedList<>();
        Queue<Person> q2 = new LinkedList<>();
        Queue<Person> q3 = new LinkedList<>();
        for (int i = 0; i < n; i++) {
            String name = sc.next();
            String surname = sc.next();
            int book1 = sc.nextInt();
            int book2 = sc.nextInt();
            int book3 = sc.nextInt();

            Person p = new Person(name, surname, book1, book2, book3);

            if (book1 == 1){
                q1.add(p);
            }

            else if (book2 == 1){
                q2.add(p);
            }

            else if (book3 == 1){
                q3.add(p);
            }

        }

        while (!q1.isEmpty()){
            Person p = q1.poll();
            if (p.book2 == 0 && p.book3 == 0){
                System.out.println(p.name + " " + p.surname);
            } else if (p.book2 == 1) {
                q2.add(p);
            }else {
                q3.add(p);
            }
        }

        while (!q2.isEmpty()){
            Person p = q2.poll();
            if (p.book3 == 0){
                System.out.println(p.name + " " + p.surname);
            }else{
                q3.add(p);
            }
        }

        while (!q3.isEmpty()){
            Person p = q3.poll();
            System.out.println(p.name + " " + p.surname);
        }


    }


}
