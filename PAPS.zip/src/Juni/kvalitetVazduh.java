package Juni;

import java.util.*;



public class kvalitetVazduh {

    public static class Naselba {
        String name;
        String pm;

        public Naselba(String name, String pm) {
            this.name = name;
            this.pm = pm;
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) return false;
            Naselba naselba = (Naselba) o;
            return Objects.equals(name, naselba.name) && Objects.equals(pm, naselba.pm);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name, pm);
        }

        @Override
        public String toString() {
            return name + " " + pm;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        CBHT<String, Naselba> table = new CBHT<>(n * 2);
        for (int i = 0; i < n; i++) {
            String name = sc.next();
            String pm = sc.next();

            Naselba naselba = new Naselba(name, pm);

            table.insert(name, naselba);

        }

        String tester = sc.next();
        int count = 0;
        double sobereni = 0.00;



        for (int i=0; i<table.buckets.length; i++){
            SLLNode<MapEntry<String, Naselba>> currNode = table.buckets[i];

            while (currNode != null){

                MapEntry<String, Naselba> momentalen = currNode.element;

                if (momentalen.key.equals(tester)){
                    count++;
                    sobereni += Double.parseDouble(momentalen.value.pm);
                }

                currNode = currNode.succ;
            }
        }

        double prosek = sobereni / count;

        System.out.printf(Locale.US, "%.2f\n", prosek);



    }
}
