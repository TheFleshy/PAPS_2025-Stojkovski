package Juni;

import java.util.*;

public class lanskiJunska {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        DLL<Integer> list = new DLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.nextInt());
        }

        System.out.println(list);

        DLLNode<Integer> node = list.getFirst();

        if (node.element >= node.succ.element){     //TODO TUKA SE RESIHME SO PRVITE DVA SAMO OTI MORA DA BIDAT STROGO U RASTECKI
            list.delete(node.succ);
        }

        DLLNode<Integer> current = list.getFirst();
        boolean less = true; // Прво споредување очекуваме A < B

        while (current != null && current.succ != null) {
            if (less) {
                if (current.element >= current.succ.element) {
                    list.delete(current.succ);
                } else {
                    current = current.succ;
                    less = !less; // следното споредување ќе биде >
                }
            } else {
                if (current.element <= current.succ.element) {
                    list.delete(current.succ);
                } else {
                    current = current.succ;
                    less = !less; // следното ќе биде <
                }
            }
        }


        System.out.println(list);

    }

}
