package Juni;

import java.util.*;

public class lista2023 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();


        SLL<Integer> list = new SLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.nextInt());
        }

        int m = sc.nextInt();
        int k = sc.nextInt();

        SLLNode<Integer> node = list.getFirst();

        while (node != null) {

            for (int i = 0; i < m; i++) {
                node = node.succ;
            }


            for (int i = 0; i < k; i++) {
                list.delete(node);
                node = node.succ;
            }

        }
        System.out.println(list);

    }

}
