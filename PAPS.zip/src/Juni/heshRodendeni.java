package Juni;

import java.util.*;

public class heshRodendeni {

    public static class Person {
        String name;
        String surname;
        String dateOfBirth;

        public Person(String name, String surname, String dateOfBirth) {
            this.name = name;
            this.surname = surname;
            this.dateOfBirth = dateOfBirth;
        }

        @Override
        public String toString() {
            return name + " " + surname + " " + dateOfBirth;
        }

        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) return false;
            Person person = (Person) o;
            return Objects.equals(name, person.name) && Objects.equals(surname, person.surname) && Objects.equals(dateOfBirth, person.dateOfBirth);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name, surname, dateOfBirth);
        }

        public String getName() {
            return name;
        }
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        CBHT<String, Person> table = new CBHT<>(n*2);

        for (int i = 0; i < n; i++) {
            String name = sc.next();
            String surname = sc.next();
            String dateOfBirth = sc.next();
            Person person = new Person(name, surname, dateOfBirth);

            String [] data = dateOfBirth.split("/");
            String datapotrebna = data[0] + "/" + data[1];

            table.insert(datapotrebna, person);
        }

        String tester = sc.next();
        String [] testerSpliter = tester.split("/");
        String testerReal = testerSpliter[0] + "/" + testerSpliter[1];
        List<String> people = new ArrayList<>();

        for (int i=0; i<table.buckets.length; i++){
            SLLNode<MapEntry<String, Person>> currNode = table.buckets[i];
            while (currNode != null){
                MapEntry<String, Person> currPerson = currNode.element;

                if (currPerson.key.equals(testerReal)){
                    String [] data = currPerson.value.toString().split("/");
                    String year = data[2];
                    int yearInt = Integer.parseInt(year);

                    String [] data2 = tester.split("/");
                    String year2 = data2[2];
                    int yearInt2 = Integer.parseInt(year2);

                    int godinki = yearInt2 - yearInt;

                    people.add(currPerson.value.name + " " + godinki);
                }


                currNode = currNode.succ;
            }
        }

        for (int i=0; i<people.size(); i++){
            System.out.println(people.get(i));

        }
    }
}
