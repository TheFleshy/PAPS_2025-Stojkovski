package Juni;

import java.util.*;

public class tretaLista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        int n = sc.nextInt();

        SLL<String> list = new SLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.next());
        }

        int l = sc.nextInt();

        SLLNode<String> node = list.getFirst();

        System.out.println(list);

        while (node != null) {

            if (node.element.length() > l){
                list.insertBefore("Outlier", node);
//                node = node.succ;
            }

            node = node.succ;
        }

        System.out.println(list);

    }


}
