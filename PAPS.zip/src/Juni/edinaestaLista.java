package Juni;

import java.util.*;

public class edinaestaLista {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        DLL<Integer> list = new DLL<>();
        for (int i = 0; i < n; i++) {
            list.insertLast(sc.nextInt());
        }

        int k = sc.nextInt();


        System.out.println(list);

        DLL<Integer> listDodadeni = new DLL<>();

        DLLNode<Integer> nodePosleden = list.getLast();


        for (int i = 0; i < k; i++) {
            listDodadeni.insertLast(nodePosleden.element);
            list.delete(nodePosleden);
            nodePosleden = nodePosleden.pred;
        }

        DLLNode<Integer> nodeDodadeni = listDodadeni.getFirst();

        while (nodeDodadeni != null) {

            list.insertFirst(nodeDodadeni.element);
            listDodadeni.delete(nodeDodadeni);

            nodeDodadeni = nodeDodadeni.succ;
        }

        System.out.println(list);


    }
}
