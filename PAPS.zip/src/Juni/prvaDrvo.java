package Juni;

import javax.swing.tree.TreeNode;
import java.util.*;

public class prvaDrvo {

    static class TreeNode {
        int value;
        List<TreeNode> children;

        public TreeNode(int value) {
            this.value = value;
            this.children = new ArrayList<>();
        }
    }

    static Map<Integer, TreeNode> nodes = new HashMap<>();
    static TreeNode root;

    public static int countLeaves(TreeNode node) {
        if (node.children.isEmpty()) {
            return 1;
        }

        int leafCount = 0;
        for (TreeNode child : node.children) {
            leafCount += countLeaves(child);
        }
        return leafCount;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int q = sc.nextInt();
        sc.nextLine();


        for (int i = 0; i < n+q; i++) {
            String [] input = sc.nextLine().split(" ");
            if (input[0].equals("root")) {
                int rootIndex = Integer.parseInt(input[1]);
                root = new TreeNode(rootIndex);
                nodes.put(rootIndex, root);

            }else if (input[0].equals("add")) {
                int parentIndex = Integer.parseInt(input[1]);
                int childIndex = Integer.parseInt(input[2]);

                TreeNode parentNode = nodes.get(parentIndex);
                TreeNode childNode = new TreeNode(childIndex);
                parentNode.children.add(childNode);
                nodes.put(childIndex, childNode);
            }else if (input[0].equals("ask")) {
                int nodeIndex = Integer.parseInt(input[1]);
                TreeNode node = nodes.get(nodeIndex);
                int leafCount = countLeaves(node);
                System.out.println(leafCount);
            }

        }


    }


}
