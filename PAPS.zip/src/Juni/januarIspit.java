package Juni;

import java.util.*;
import java.util.Stack;

public class januarIspit {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        sc.nextLine();

        Stack<String> stack = new Stack<>();

        boolean eDobar = true;
        boolean unatreText = false;

        for (int i = 0; i < n; i++) {

            String input = sc.nextLine();


            if (input.contains("begin")) {
                String toPut = input.substring(6);

                if (!stack.isEmpty() && stack.peek().equals("{subsection}") && toPut.equals("{section}") && !unatreText) {
                    eDobar = false;
                    break;
                }

                if (toPut.equals("{text}")) {
                    unatreText = true;
                } else if (unatreText && (toPut.equals("{section}") || toPut.equals("{subsection}"))) {
                    eDobar = false;
                    break;
                }

                stack.push(toPut);
            } else if (input.contains("end")) {
                String inputCut = input.substring(4);

                if (stack.isEmpty() || !stack.peek().equals(inputCut)) {
                    eDobar = false;
                    break;
                }

                if (inputCut.equals("{text}")) {
                    unatreText = false;
                }
                stack.pop();

            } else {
                if (!unatreText) {
                    eDobar = false;
                    break;
                }
            }

        }

        if (eDobar && stack.isEmpty()) {
            System.out.println("true");
        } else {
            System.out.println("false");
        }


    }

}
