package Juni;
import java.util.*;

public class kmestaDesno {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        DLL<Integer> list = new DLL<>();

        for (int i = 0; i < n; i++) {
            list.insertLast(sc.nextInt());
        }

        System.out.println(list);

        int m = sc.nextInt();
        int k = sc.nextInt();

        DLLNode<Integer> najden = list.find(m);


        for (int i = 0; i < k; i++) {
            if (najden == null)break;
            DLLNode<Integer> next = najden.succ;

            DLLNode<Integer> first = list.getFirst();
            if (next != null) {
                list.insertAfter(najden.element, next);
                list.delete(najden);
                najden = next.succ;
            }else{
                list.insertBefore(najden.element, first);
                list.delete(najden);
                najden = first.pred;
            }
        }

        System.out.println(list);



    }
}
