//package Kolokvium2;
//
//import java.io.InputStream;
//import java.io.Reader;
//
//public class InputStreamReader extends Reader {
//    public InputStreamReader(InputStream in) {
//    }
//}
