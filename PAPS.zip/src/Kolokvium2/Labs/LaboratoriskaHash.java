//package Kolokvium2.Labs;
//
//import java.util.Map;
//import java.util.Scanner;
//
//
// class CBHT<K extends Comparable<K>, E> {
//
//    // An object of class CBHT is a closed-bucket hash table, containing
//    // entries of class MapEntry.
//    private SLLNode<MapEntry<K, E>>[] buckets;
//
//    @SuppressWarnings("unchecked")
//    public CBHT(int m) {
//        // Construct an empty CBHT with m buckets.
//        buckets = (SLLNode<MapEntry<K, E>>[]) new SLLNode[m];
//    }
//
//    private int hash(K key) {
//        // Translate key to an index of the array buckets.
//        return Math.abs(key.hashCode()) % buckets.length;
//    }
//
//    public SLLNode<MapEntry<K, E>> search(K targetKey) {
//        // Find which if any node of this CBHT contains an entry whose key is equal to targetKey.
//        // Return a link to that node (or null if there is none).
//        int b = hash(targetKey);
//        SLLNode<MapEntry<K, E>> currNode = buckets[b];
//        while (currNode != null) {
//            MapEntry<K, E> currEntry = currNode.element;
//            if (currEntry.key.equals(targetKey)) return currNode;
//            else currNode = currNode.succ;
//        }
//        return null;
//    }
//
//    public void insert(K key, E val) {
//        // Insert the entry <key, val> into this CBHT.
//        // If entry with same key exists, overwrite it.
//        MapEntry<K, E> newEntry = new MapEntry<>(key, val);
//        int b = hash(key);
//        SLLNode<MapEntry<K, E>> currNode = buckets[b];
//        while (currNode != null) {
//            MapEntry<K, E> currEntry = currNode.element;
//            if (currEntry.key.equals(key)) {
//                // Make newEntry replace the existing entry ...
//                currNode.element = newEntry;
//                return;
//            } else currNode = currNode.succ;
//        }
//        // Insert newEntry at the front of the SLL in bucket b ...
//        buckets[b] = new SLLNode<>(newEntry, buckets[b]);
//    }
//
//    public void delete(K key) {
//        // Delete the entry (if any) whose key is equal to key from this CBHT.
//        int b = hash(key);
//        SLLNode<MapEntry<K, E>> predNode = null, currNode = buckets[b];
//        while (currNode != null) {
//            MapEntry<K, E> currEntry = currNode.element;
//            if (currEntry.key.equals(key)) {
//                if (predNode == null) buckets[b] = currNode.succ;
//                else predNode.succ = currNode.succ;
//                return;
//            } else {
//                predNode = currNode;
//                currNode = currNode.succ;
//            }
//        }
//    }
//
//    public String toString() {
//        String temp = "";
//        for (int i = 0; i < buckets.length; i++) {
//            temp += i + ":";
//            SLLNode<MapEntry<K, E>> curr = buckets[i];
//            while (curr != null) {
//                temp += curr.element.toString() + " ";
//                curr = curr.succ;
//            }
//            temp += "\n";
//        }
//        return temp;
//    }
//}
//
// class MapEntry<K extends Comparable<K>, E> {
//    // Each MapEntry object is a pair consisting of a key (a Comparable object)
//    // and a value (an arbitrary object).
//    K key;
//    E value;
//
//    public MapEntry(K key, E val) {
//        this.key = key;
//        this.value = val;
//    }
//
//    public String toString() {
//        return "<" + key + "," + value + ">";
//    }
//}
//
// class SLLNode<E> {
//    protected E element;
//    protected SLLNode<E> succ;
//
//    public SLLNode(E elem, SLLNode<E> succ) {
//        this.element = elem;
//        this.succ = succ;
//    }
//
//    @Override
//    public String toString() {
//        return element.toString();
//    }
//}
//
//
//
//class Covek{
//    String ime, prezime;
//    Integer budzet;
//    String ip, vreme, grad;
//    Integer cena;
//
//    public Covek(String ime, String prezime, Integer budzet, String ip, String vreme, String grad, Integer cena) {
//        this.ime = ime;
//        this.prezime = prezime;
//        this.budzet = budzet;
//        this.ip = ip;
//        this.vreme = vreme;
//        this.grad = grad;
//        this.cena = cena;
//    }
//
//}
//public class LaboratoriskaHash {
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        int n = sc.nextInt();
//        CBHT<String, Integer> tabela1 = new CBHT<>(n);
//        CBHT<String, Covek> tabela2 = new CBHT<>(n);
//        for(int i = 0; i < n; i++){
//            Covek c = new Covek(sc.next(), sc.next(), sc.nextInt(), sc.next(), sc.next(), sc.next(), sc.nextInt());
//
//            String[] newIpArray = c.ip.split("\\.");
//            String newIp = newIpArray[0]+"."+newIpArray[1]+"."+newIpArray[2];
//
//            SLLNode<MapEntry<String, Integer>> imaVeke = tabela1.search(newIp);
//            if(imaVeke == null){
//                tabela1.insert(newIp, 1);
//                tabela2.insert(newIp, c);
//            } else{
//                int brojLuge = imaVeke.element.value;
//                imaVeke.element.value = brojLuge + 1;
//
//                SLLNode<MapEntry<String, Covek>> covekVoTabela = tabela2.search(newIp);
//                Covek covek = covekVoTabela.element.value;
//                if(c.cena > covek.cena){
//                    covekVoTabela.element.value = c;
//                }
//            }
//        }
//        int m = sc.nextInt();
//        for(int i = 0; i < m; i++){
//            Covek tester = new Covek(sc.next(), sc.next(), sc.nextInt(), sc.next(), sc.next(), sc.next(), sc.nextInt());
//            String[] newIpArray = tester.ip.split("\\.");
//            String newIp = newIpArray[0]+"."+newIpArray[1]+"."+newIpArray[2];
//
//            int brLuge = tabela1.search(newIp).element.value;
//            System.out.println("IP network: "+newIp+" has the following number of users:");
//            System.out.println(brLuge);
//
//            Covek najvekePlatil = tabela2.search(newIp).element.value;
//            System.out.println("The user who spent the most from that network is:");
//            System.out.println(najvekePlatil.ime+" "+najvekePlatil.prezime+" with salary "+najvekePlatil.budzet+" from address "+najvekePlatil.ip+" who spent "+najvekePlatil.cena);
//        }
//    }
//}
////2
////bojan spasovski 222 122.1.2.3 13:30 Vinica 200
////andrej sotjv 21 213.21.12 s12sad sd 200
//
////На влез во оваа задача ќе ви бидат дадени редови како следниот формат:
////Ime Prezime budzet ip_adresa vreme grad cena
////Пример:
////Jovan Todorov 1000 10.73.112.200 15:30 Bitola 700
////Кое што значи дека лицето со Име и Презиме Jovan Todorov, има буџет од 1000 денарари, има ип адреса со мрежа 10.73.112 и домаќин 200, и се приклучува во 15:30 часот за да купи билет кон Bitola кој што чини 760 денари
////
////Ќе ви бидат дадени N такви редови, по што ќе следи празен ред па уште М редови од истиот формат, кои ќе ги користиме за тестирање
////Од редот за тестирање треба да ја извадите IP адресата на мрежата и потоа да го одговорите следното прашање со оваа мрежа:
////
////Од сите Н лица на влез, кои што сес поврзуваат со истата мрежа (од било кој домаќин во мрежата)
////колку од нив имале доволно буџет за да го купат билетот и од овие, кој од нив платил најголем износ
////(доколку има повеќе со ист најголем износ, тогаш кој е првиот таков во влезот?) Секогаш ќе постои барем еден таков
////Ова ќе треба да го направите за сите М редови за тестирање
////Препорака користете OBHT и/или CBHT
////
////5
////Jovan Todorov 1000 10.73.112.200 16:30 Bitola 760
////Mitko Jonev 4350 132.20.112.200 12:15 Kumanovo 6000
////Sara Dobreva 4800 10.73.60.29 11:35 Bitola 4100
////Monce Trajanova 4000 10.75.112.112 15:25 Bitola 4100
////Viktor Jovev 2200 10.73.112.79 15:15 Strumica 3600
////
////2
////Jovan Todorov 1000 10.73.112.200 15:30 Bitola 760
////Monce Trajanova 4000 10.75.112.112 15:25 Bitola 4100
//
////IP network: 10.73.112 has the following number of users:
////2
////The user who spent the most from that network is:
////Viktor Jovev with salary 2200 from address 10.73.113.79 who spent 3600
//
//// CBHT tabela1<String, Integer>    tabela1(10.73.112).element.value = 2
////
//// Tabela 1
//// Key                  Value
//// 10.73.112                2
//// 132.20.112               1
//// 10.73.60                 1
//// 10.75.112                1
////
//// CBHT tabela2<String, Person>
//// Tabela 2
//// Key                  Value
//// 10.73.112            jovan
//// 132.20.112           mitko
//// 10.73.60             sara
//// 10.75.112            monce