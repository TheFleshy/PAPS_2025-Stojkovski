package Kolokvium2.Labs;

import java.util.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class tretata {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        AdjacencyListGraph<String> graf = new AdjacencyListGraph<>();
        Map<String, Integer> map = new HashMap<>();
        for (int i = 0; i < N; i++) {
            String s = sc.next();
            int cema = sc.nextInt();
            graf.addVertex(s);
            map.put(s, cema);
        }
        int M = sc.nextInt();
        for (int i = 0; i < M; i++) {
            String modulFr = sc.next();
            String modulTo = sc.next();
            graf.addEdge(modulTo, modulFr);
        }
        System.out.println(graf.topologicalSort(map));
    }


    static class AdjacencyListGraph<T> {
        private Map<T, Set<T>> adjacencyList;

        public AdjacencyListGraph() {
            this.adjacencyList = new HashMap<>();
        }

        public void addVertex(T vertex) {
            if (!adjacencyList.containsKey(vertex)) {
                adjacencyList.put(vertex, new HashSet<>());
            }
        }

        public void addEdge(T source, T destination) {
            addVertex(source);
            addVertex(destination);
            adjacencyList.get(source).add(destination);
        }

        public Set<T> getNeighbors(T vertex) {
            return adjacencyList.getOrDefault(vertex, new HashSet<>());
        }

        private void topologicalSortUtil(T vertex, Set<T> visited, Stack<T> stack) {
            visited.add(vertex);
            for (T neighbor : getNeighbors(vertex)) {
                if (!visited.contains(neighbor)) {
                    topologicalSortUtil(neighbor, visited, stack);
                }
            }
            stack.push(vertex);
        }

        public Integer topologicalSort(Map<String, Integer> map) {
            Stack<T> stack = new Stack<>();
            Set<T> visited = new HashSet<>();
            Map<T, Integer> timeMap = new HashMap<>();

            for (T vertex : adjacencyList.keySet()) {
                if (!visited.contains(vertex)) {
                    topologicalSortUtil(vertex, visited, stack);
                }
            }

            while (!stack.isEmpty()) {
                T current = stack.pop();
                int currentTime = map.get(current);

                timeMap.putIfAbsent(current, currentTime);

                for (T neighbor : getNeighbors(current)) {
                    int neighborTime = timeMap.getOrDefault(neighbor, 0);
                    timeMap.put(neighbor, Math.max(neighborTime, timeMap.get(current) + map.get(neighbor)));
                }
            }

            return timeMap.values().stream().max(Integer::compare).orElse(0);
        }

        @Override
        public String toString() {
            StringBuilder ret = new StringBuilder();
            for (Map.Entry<T, Set<T>> vertex : adjacencyList.entrySet())
                ret.append(vertex.getKey()).append(": ").append(vertex.getValue()).append("\n");
            return ret.toString();
        }
    }
}

