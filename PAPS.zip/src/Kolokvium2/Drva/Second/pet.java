package Kolokvium2.Drva.Second;
import java.util.*;

public class pet {
    // „која е сумата на степените во поддрвото на избран јазол“.

    public static int sumaStepeni(BNode<String> node){
        if (node == null){
            return 0;
        }

        int brojacLevo = (node.left != null) ? 1 : 0;
        int brojacDesno = (node.right != null) ? 1 : 0;

        return brojacLevo + brojacDesno + sumaStepeni(node.left) + sumaStepeni(node.right);

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int q = sc.nextInt();
        sc.nextLine();

        BTree<String> tree = new BTree<>();
        Map<String, BNode<String>> node = new HashMap<>();

        for (int i=0; i<n+q; i++){
            String[] input = sc.nextLine().split(" ");

            if (input[0].equals("root")){
                tree.makeRoot(input[1]);
                BNode<String> root = tree.root;
                node.put(input[1], root);
            }else if (input[0].equals("add")){
                BNode<String> parent = node.get(input[1]);

                if (input[3].equals("LEFT")){
                    BNode<String> leftChild = tree.addChild(parent, 1, input[2]);
                    node.put(input[2], leftChild);
                }else if (input[3].equals("RIGHT")){
                    BNode<String> rightChild = tree.addChild(parent, 2, input[2]);
                    node.put(input[2], rightChild);
                }
            }else {
                BNode<String> subNode = node.get(input[1]);
                int suma = sumaStepeni(subNode);
                System.out.println(suma);
            }
        }
    }

}
