package Kolokvium2.Drva;

import java.util.*;

public class sumaSitePatista {

    public static String suma(BNode<Integer> node) {
        if (node == null) {
            return "";
        }

        String levo = node.info.toString() + suma(node.left);
        String desno = node.info.toString() + suma(node.right);

        return node.info.toString() + suma(node.left) + suma(node.right);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        sc.nextLine();

        BTree<Integer> tree = new BTree<>();
        Map<Integer, BNode<Integer>> node = new HashMap<>();

        for (int i = 0; i < n; i++) {
            String[] input = sc.nextLine().split(" ");

            if (input[0].equals("root")) {
                tree.makeRoot(Integer.parseInt(input[1]));
                BNode<Integer> root = tree.root;
                node.put(Integer.parseInt(input[1]), root);
            } else if (input[0].equals("add")) {
                BNode<Integer> parent = node.get(Integer.parseInt(input[1]));
                if (input[3].equals("LEFT")) {
                    BNode<Integer> leftChild = tree.addChild(parent, 1, Integer.parseInt(input[2]));
                    node.put(Integer.parseInt(input[2]), leftChild);
                } else if (input[3].equals("RIGHT")) {
                    BNode<Integer> rightChild = tree.addChild(parent, 2, Integer.parseInt(input[2]));
                    node.put(Integer.parseInt(input[2]), rightChild);
                }
            }

        }

        String result = suma(tree.root);
        System.out.println(result);

    }
}
