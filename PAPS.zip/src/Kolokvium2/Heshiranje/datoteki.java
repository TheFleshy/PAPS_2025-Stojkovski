package Kolokvium2.Heshiranje;
import java.util.*;

public class datoteki {

    static public class CBHT<K extends Comparable<K>, E> {

        // An object of class CBHT is a closed-bucket hash table, containing
        // entries of class MapEntry.
        private SLLNode<MapEntry<K, E>>[] buckets;

        @SuppressWarnings("unchecked")
        public CBHT(int m) {
            // Construct an empty CBHT with m buckets.
            buckets = (SLLNode<MapEntry<K, E>>[]) new SLLNode[m];
        }

        private int hash(K key) {
            // Translate key to an index of the array buckets.
            return Math.abs(key.hashCode()) % buckets.length;
        }

        public SLLNode<MapEntry<K, E>> search(K targetKey) {
            // Find which if any node of this CBHT contains an entry whose key is equal to targetKey.
            // Return a link to that node (or null if there is none).
            int b = hash(targetKey);
            SLLNode<MapEntry<K, E>> currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(targetKey)) return currNode;
                else currNode = currNode.succ;
            }
            return null;
        }

        public void insert(K key, E val) {
            // Insert the entry <key, val> into this CBHT.
            // If entry with same key exists, overwrite it.
            MapEntry<K, E> newEntry = new MapEntry<>(key, val);
            int b = hash(key);
            SLLNode<MapEntry<K, E>> currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(key)) {
                    // Make newEntry replace the existing entry ...
//                    currNode.element = newEntry;
//                    return;
                    break;
                } else currNode = currNode.succ;
            }
            // Insert newEntry at the front of the SLL in bucket b ...
            buckets[b] = new SLLNode<>(newEntry, buckets[b]);
        }

        public void delete(K key) {
            // Delete the entry (if any) whose key is equal to key from this CBHT.
            int b = hash(key);
            SLLNode<MapEntry<K, E>> predNode = null, currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(key)) {
                    if (predNode == null) buckets[b] = currNode.succ;
                    else predNode.succ = currNode.succ;
                    return;
                } else {
                    predNode = currNode;
                    currNode = currNode.succ;
                }
            }
        }

        public String toString() {
            String temp = "";
            for (int i = 0; i < buckets.length; i++) {
                temp += i + ":";
                SLLNode<MapEntry<K, E>> curr = buckets[i];
                while (curr != null) {
                    temp += curr.element.toString() + " ";
                    curr = curr.succ;
                }
                temp += "\n";
            }
            return temp;
        }
    }
    static public class MapEntry<K extends Comparable<K>, E> {
        // Each MapEntry object is a pair consisting of a key (a Comparable object)
        // and a value (an arbitrary object).
        K key;
        E value;

        public MapEntry(K key, E val) {
            this.key = key;
            this.value = val;
        }

        public String toString() {
            return "<" + key + "," + value + ">";
        }
    }
    static public class SLLNode<E> {
        protected E element;
        protected SLLNode<E> succ;

        public SLLNode(E elem, SLLNode<E> succ) {
            this.element = elem;
            this.succ = succ;
        }

        @Override
        public String toString() {
            return element.toString();
        }
    }

    public static class File{
        String ime, content;

        public File(String ime, String content) {
            this.ime = ime;
            this.content = content;
        }

        @Override
        public String toString() {
            return ime + " " + content;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        CBHT<String, File> table = new CBHT<>(2*n);
        for (int i = 0; i < n; i++) {
            String path = sc.next();
            String file = sc.next();
            String content = sc.next();
            File f = new File(file, content);
            table.insert(path, f);
        }

        int m = sc.nextInt();
        for(int i=0; i<m; i++) {
            String func = sc.next();
            if(func.equals("add")){
                String path = sc.next();
                String file = sc.next();
                String content = sc.next();
                File f = new File(file, content);
                table.insert(path, f);
            } else if(func.equals("delete")){
                String path = sc.next();
                String file = sc.next();
                String content = sc.next();
                for(int j = 0; j < table.buckets.length; j++){
                    SLLNode<MapEntry<String, File>> node = table.buckets[j];
                    while(node != null){
                        MapEntry<String, File> current = node.element;
                        if(current.key.equals(path)){
                            if(current.value.ime.equals(file) && current.value.content.equals(content)){
//                                current.value.ime = "";
//                                current.value.content = "";
//                                break;
                                table.delete(path);
                            }
                        }
                        node = node.succ;
                    }
                }
            } else{
                String path = sc.next();
                String file = sc.next();
                String content = sc.next();
                int flag = 0;
                for(int j = 0; j < table.buckets.length; j++){
                    SLLNode<MapEntry<String, File>> node = table.buckets[j];
                    while(node != null){
                        MapEntry<String, File> current = node.element;
                        if(current.key.equals(path)){
                            if(current.value != null && current.value.ime.equals(file) && current.value.content.equals(content)){
                                System.out.println("true");
                                flag = 1;
                                break;
                            }
                        }
                        node = node.succ;
                    }
                }
                if(flag == 0){
                    System.out.println("false");
                }
            }
        }
        String posleden = sc.next();
        for(int j = 0; j < table.buckets.length; j++){
            SLLNode<MapEntry<String, File>> node = table.buckets[j];
            while(node != null){
                MapEntry<String, File> current = node.element;
                if( current.value != null && current.value.content.equals(posleden)){
                    System.out.println(current.key + "/" + current.value.ime);
                }
                node = node.succ;
            }
        }
    }

}

/*
2
root/a/ 1.txt (abcd)
root/a/ 2.txt (efgh)
3
add root/c/d/ 4.txt (efgh)
delete root/a/ 1.txt (abcd)
find root/a/ 2.txt (abcd)
efgh

 */
