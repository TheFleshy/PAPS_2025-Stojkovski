package Kolokvium2.Heshiranje;
import java.util.Scanner;

public class apas {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CBHT<String, Integer> cbht = new CBHT<>(10);
        cbht.insert("a",1);
        cbht.insert("b",1);
        cbht.insert("c",5);
        cbht.insert("a",10);
        cbht.insert("a",15);
        System.out.println(cbht);

        SLLNode<MapEntry<String, Integer>> listNode = cbht.search("a");
        while(listNode != null) {
            if(listNode.element.value == 15){
                cbht.delete(listNode.element.key);
            }
            if(listNode.succ != null && listNode.succ.element.value == 1){
                listNode.succ = listNode.succ.succ;
            }
            listNode = listNode.succ;
        }
        System.out.println(cbht);

        System.out.println("abcd".substring(0,2));

    }
}
