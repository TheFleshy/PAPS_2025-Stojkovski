package Kolokvium2.Heshiranje;

import java.util.*;

public class zadaca4 {

    static public class CBHT<K extends Comparable<K>, E> {

        // An object of class CBHT is a closed-bucket hash table, containing
        // entries of class MapEntry.
        private SLLNode<MapEntry<K, E>>[] buckets;

        @SuppressWarnings("unchecked")
        public CBHT(int m) {
            // Construct an empty CBHT with m buckets.
            buckets = (SLLNode<MapEntry<K, E>>[]) new SLLNode[m];
        }

        private int hash(K key) {
            // Translate key to an index of the array buckets.
            return Math.abs(key.hashCode()) % buckets.length;
        }

        public SLLNode<MapEntry<K, E>> search(K targetKey) {
            // Find which if any node of this CBHT contains an entry whose key is equal to targetKey.
            // Return a link to that node (or null if there is none).
            int b = hash(targetKey);
            SLLNode<MapEntry<K, E>> currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(targetKey)) return currNode;
                else currNode = currNode.succ;
            }
            return null;
        }

        public void insert(K key, E val) {
            // Insert the entry <key, val> into this CBHT.
            // If entry with same key exists, overwrite it.
            MapEntry<K, E> newEntry = new MapEntry<>(key, val);
            int b = hash(key);
            SLLNode<MapEntry<K, E>> currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(key)) {
                    // Make newEntry replace the existing entry ...
//                    currNode.element = newEntry;
//                    return;
                    break;
                } else currNode = currNode.succ;
            }
            // Insert newEntry at the front of the SLL in bucket b ...
            buckets[b] = new SLLNode<>(newEntry, buckets[b]);
        }

        public void delete(K key) {
            // Delete the entry (if any) whose key is equal to key from this CBHT.
            int b = hash(key);
            SLLNode<MapEntry<K, E>> predNode = null, currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(key)) {
                    if (predNode == null) buckets[b] = currNode.succ;
                    else predNode.succ = currNode.succ;
                    return;
                } else {
                    predNode = currNode;
                    currNode = currNode.succ;
                }
            }
        }

        public String toString() {
            String temp = "";
            for (int i = 0; i < buckets.length; i++) {
                temp += i + ":";
                SLLNode<MapEntry<K, E>> curr = buckets[i];
                while (curr != null) {
                    temp += curr.element.toString() + " ";
                    curr = curr.succ;
                }
                temp += "\n";
            }
            return temp;
        }
    }

    static public class MapEntry<K extends Comparable<K>, E> {
        // Each MapEntry object is a pair consisting of a key (a Comparable object)
        // and a value (an arbitrary object).
        K key;
        E value;

        public MapEntry(K key, E val) {
            this.key = key;
            this.value = val;
        }

        public String toString() {
            return "<" + key + "," + value + ">";
        }
    }

    static public class SLLNode<E> {
        protected E element;
        protected SLLNode<E> succ;

        public SLLNode(E elem, SLLNode<E> succ) {
            this.element = elem;
            this.succ = succ;
        }

        @Override
        public String toString() {
            return element.toString();
        }
    }

    static class Person {
        String name, surname;
        Integer budget;
        String ip;
        String time;
        String city;
        Integer price;

        public Person(String name, String surname, Integer budget, String ip, String time, String city, Integer price) {
            this.name = name;
            this.surname = surname;
            this.budget = budget;
            this.ip = ip;
            this.time = time;
            this.city = city;
            this.price = price;
        }

        @Override
        public String toString() {
            return name + " " + surname + " " + budget + " " + ip + " " + time + " " + city + " " + price;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        CBHT<String, Person> table = new CBHT<>(n);
        for (int i = 0; i < n; i++) {
            Person p = new Person(sc.next(), sc.next(), sc.nextInt(), sc.next(), sc.next(), sc.next(), sc.nextInt());

            int hours = Integer.parseInt(p.time.split(":")[0]);
            String[] pureIp;
            pureIp = p.ip.split("\\.");
            String testerIp = pureIp[0] + "." + pureIp[1] + "." + pureIp[2];
            if (hours >= 12) {
                table.insert(testerIp, p);
            }
        }
//        System.out.println(table);
        int m = sc.nextInt();
        for (int i = 0; i < m; i++) {
            Person p = new Person(sc.next(), sc.next(), sc.nextInt(), sc.next(), sc.next(), sc.next(), sc.nextInt());

            String[] pureIp = p.ip.split("\\.");
            String testerIp = pureIp[0] + "." + pureIp[1] + "." + pureIp[2];

            int count = 0;
            Person najrano = null;

            for (int j = 0; j < table.buckets.length; j++) {
                SLLNode<MapEntry<String, Person>> currNode = table.buckets[j];
                while (currNode != null) {
                    MapEntry<String, Person> currEntry = currNode.element;
                    Person currentPerson = currNode.element.value;

                    String[] pureIpp = currentPerson.ip.split("\\.");
                    String currentTesterIp = pureIpp[0] + "." + pureIpp[1] + "." + pureIpp[2];

                    if (currentTesterIp.equals(testerIp)) {
                        count++;
                        int hours = Integer.parseInt(currentPerson.time.split(":")[0]);
//                        int minutes = Integer.parseInt(currentPerson.time.split(":")[1]);

                        if (hours >= 12) {
                            if ((najrano == null || hours <= Integer.parseInt(najrano.time.split(":")[0]) ||
                                    (hours == Integer.parseInt(najrano.time.split(":")[0]) && Integer.parseInt(currentPerson.time.split(":")[1]) < Integer.parseInt(najrano.time.split(":")[1])))) {
                                najrano = currentPerson;
                            }
                        }
                    }
                    currNode = currNode.succ;
                }
            }

            System.out.println("IP network: " + testerIp + " has the following number of users:");
            System.out.println(count);
            System.out.println("The user who logged on earliest after noon from that network is:");
            System.out.println(najrano.name + " " + najrano.surname + " with salary " + najrano.budget + " from address " + najrano.ip + " who logged in at " + najrano.time);
            System.out.println();
        }
    }
}
