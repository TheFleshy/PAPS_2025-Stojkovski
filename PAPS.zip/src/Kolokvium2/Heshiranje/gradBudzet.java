package Kolokvium2.Heshiranje;

import java.util.*;


public class gradBudzet {
    static public class CBHT<K extends Comparable<K>, E> {

        // An object of class CBHT is a closed-bucket hash table, containing
        // entries of class MapEntry.
        private SLLNode<MapEntry<K, E>>[] buckets;

        @SuppressWarnings("unchecked")
        public CBHT(int m) {
            // Construct an empty CBHT with m buckets.
            buckets = (SLLNode<MapEntry<K, E>>[]) new SLLNode[m];
        }

        private int hash(K key) {
            // Translate key to an index of the array buckets.
            return Math.abs(key.hashCode()) % buckets.length;
        }

        public SLLNode<MapEntry<K, E>> search(K targetKey) {
            // Find which if any node of this CBHT contains an entry whose key is equal to targetKey.
            // Return a link to that node (or null if there is none).
            int b = hash(targetKey);
            SLLNode<MapEntry<K, E>> currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(targetKey)) return currNode;
                else currNode = currNode.succ;
            }
            return null;
        }

        public void insert(K key, E val) {
            // Insert the entry <key, val> into this CBHT.
            // If entry with same key exists, overwrite it.
            MapEntry<K, E> newEntry = new MapEntry<>(key, val);
            int b = hash(key);
            SLLNode<MapEntry<K, E>> currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(key)) {
                    // Make newEntry replace the existing entry ...
//                    currNode.element = newEntry;
//                    return;
                    break;
                } else currNode = currNode.succ;
            }
            // Insert newEntry at the front of the SLL in bucket b ...
            buckets[b] = new SLLNode<>(newEntry, buckets[b]);
        }

        public void delete(K key) {
            // Delete the entry (if any) whose key is equal to key from this CBHT.
            int b = hash(key);
            SLLNode<MapEntry<K, E>> predNode = null, currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(key)) {
                    if (predNode == null) buckets[b] = currNode.succ;
                    else predNode.succ = currNode.succ;
                    return;
                } else {
                    predNode = currNode;
                    currNode = currNode.succ;
                }
            }
        }

        public String toString() {
            String temp = "";
            for (int i = 0; i < buckets.length; i++) {
                temp += i + ":";
                SLLNode<MapEntry<K, E>> curr = buckets[i];
                while (curr != null) {
                    temp += curr.element.toString() + " ";
                    curr = curr.succ;
                }
                temp += "\n";
            }
            return temp;
        }
    }
    static public class MapEntry<K extends Comparable<K>, E> {
        // Each MapEntry object is a pair consisting of a key (a Comparable object)
        // and a value (an arbitrary object).
        K key;
        E value;

        public MapEntry(K key, E val) {
            this.key = key;
            this.value = val;
        }

        public String toString() {
            return "<" + key + "," + value + ">";
        }
    }

    public static class Person implements Comparable<Person> {
        String name;
        String surname;
        int budget;
        String ip;
        String time;
        String city;
        int price;

        public Person(String name, String surname, int budget, String ip, String time, String city, int price) {
            this.name = name;
            this.surname = surname;
            this.budget = budget;
            this.ip = ip;
            this.time = time;
            this.city = city;
            this.price = price;
        }

        @Override
        public String toString() {
            return name + " " + surname + " " + budget + " " + ip + " " + city + " " + price;
        }

        @Override
        public int compareTo(Person o) {
            return 0;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        CBHT<Person, String> table = new CBHT<Person, String>(2 * n);

        for (int i = 0; i < n; i++) {
            String name = sc.next();
            String surname = sc.next();
            int budget = sc.nextInt();
            String ip = sc.next();
            String time = sc.next();
            String city = sc.next();
            int price = sc.nextInt();

            Person p = new Person(name, surname, budget, ip, time, city, price);

            if (p.budget >= p.price) {
                table.insert(p, city);
            }
        }

        int m = sc.nextInt();


        for (int i = 0; i < m; i++) {
            String name = sc.next();
            String surname = sc.next();
            int budget = sc.nextInt();
            String ip = sc.next();
            String time = sc.next();
            String city = sc.next();
            int price = sc.nextInt();

            Person p = new Person(name, surname, budget, ip, time, city, price);

            int counter = 0;
            Person maxSpender = null;
            int max = Integer.MIN_VALUE;

            for (int j = 0; j < table.buckets.length; j++) {
                SLLNode<MapEntry<Person, String>> node = table.buckets[j];
                while (node != null) {
                    MapEntry<Person, String> curr = node.element;
                    if (curr.value.equals(city)) {
                        counter++;

                        Person momentalen = curr.key;
                        if (momentalen.price >= max) {
                            max = momentalen.price;
                            maxSpender = momentalen;
                        }
                    }
                    node = node.succ;
                }
            }

            System.out.println("City: "+ city + " has the following number of customers:");
            System.out.println(counter);
            System.out.println("The user who spent the most purchasing for that city is:");
            if (maxSpender != null){
                System.out.println(maxSpender.name + " " + maxSpender.surname + " with salary " + maxSpender.budget + " from address " + maxSpender.ip + " who spent " + maxSpender.price);
                System.out.println();
            }
        }
    }
}
