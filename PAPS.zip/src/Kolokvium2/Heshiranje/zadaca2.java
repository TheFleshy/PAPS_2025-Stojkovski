package Kolokvium2.Heshiranje;

import java.util.*;

public class zadaca2 {

    static public class CBHT<K extends Comparable<K>, E> {

        // An object of class CBHT is a closed-bucket hash table, containing
        // entries of class MapEntry.
        private SLLNode<MapEntry<K, E>>[] buckets;

        @SuppressWarnings("unchecked")
        public CBHT(int m) {
            // Construct an empty CBHT with m buckets.
            buckets = (SLLNode<MapEntry<K, E>>[]) new SLLNode[m];
        }

        private int hash(K key) {
            // Translate key to an index of the array buckets.
            return Math.abs(key.hashCode()) % buckets.length;
        }

        public SLLNode<MapEntry<K, E>> search(K targetKey) {
            // Find which if any node of this CBHT contains an entry whose key is equal to targetKey.
            // Return a link to that node (or null if there is none).
            int b = hash(targetKey);
            SLLNode<MapEntry<K, E>> currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(targetKey)) return currNode;
                else currNode = currNode.succ;
            }
            return null;
        }

        public void insert(K key, E val) {
            // Insert the entry <key, val> into this CBHT, allowing duplicates (multiple entries for the same key).
            MapEntry<K, E> newEntry = new MapEntry<>(key, val);
            int b = hash(key);
            SLLNode<MapEntry<K, E>> currNode = buckets[b];

            // Search through the linked list for an existing key
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(key)) {
                    // If the key is found, just add a new node without modifying existing entries
                    break; // We will add the new person regardless if we found the key
                } else {
                    currNode = currNode.succ;
                }
            }

            // Insert newEntry at the front of the SLL in bucket b, allowing duplicates.
            buckets[b] = new SLLNode<>(newEntry, buckets[b]);
        }


        public void delete(K key) {
            // Delete the entry (if any) whose key is equal to key from this CBHT.
            int b = hash(key);
            SLLNode<MapEntry<K, E>> predNode = null, currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(key)) {
                    if (predNode == null) buckets[b] = currNode.succ;
                    else predNode.succ = currNode.succ;
                    return;
                } else {
                    predNode = currNode;
                    currNode = currNode.succ;
                }
            }
        }

        public String toString() {
            String temp = "";
            for (int i = 0; i < buckets.length; i++) {
                temp += i + ":";
                SLLNode<MapEntry<K, E>> curr = buckets[i];
                while (curr != null) {
                    temp += curr.element.toString() + " ";
                    curr = curr.succ;
                }
                temp += "\n";
            }
            return temp;
        }
    }


    static class MapEntry<K extends Comparable<K>, E> {
        // Each MapEntry object is a pair consisting of a key (a Comparable object)
        // and a value (an arbitrary object).
        K key;
        E value;

        public MapEntry(K key, E val) {
            this.key = key;
            this.value = val;
        }

        public String toString() {
            return "<" + key + "," + value + ">";
        }
    }

    static public class SLLNode<E> {
        protected E element;
        protected SLLNode<E> succ;

        public SLLNode(E elem, SLLNode<E> succ) {
            this.element = elem;
            this.succ = succ;
        }

        @Override
        public String toString() {
            return element.toString();
        }
    }


    static public class Person {
        String name, surname;
        int budget;
        String ip, time, city;
        int amount;

        public Person(String name, String surname, int budget, String ip, String time, String city, int amount) {
            this.name = name;
            this.surname = surname;
            this.budget = budget;
            this.ip = ip;
            this.time = time;
            this.city = city;
            this.amount = amount;
        }

        @Override
        public String toString() {
            return name + " " + surname + " " + budget + " " + ip + " " + time + " " + city + " " + amount;
        }

        public boolean buyTicket() {
            return budget - amount >= 0;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Person person = (Person) o;
            return budget == person.budget && amount == person.amount && Objects.equals(name, person.name) && Objects.equals(surname, person.surname) && Objects.equals(ip, person.ip) && Objects.equals(time, person.time) && Objects.equals(city, person.city);
        }

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        CBHT<String, Person> tabela1 = new CBHT<>(n * 2);

        for (int i = 0; i < n; i++) {
            String name = sc.next();
            String surname = sc.next();
            int budget = sc.nextInt();
            String ip = sc.next();
            String time = sc.next();
            String city = sc.next();
            int amount = sc.nextInt();

            Person p = new Person(name, surname, budget, ip, time, city, amount);
            if (p.buyTicket()) {
                tabela1.insert(city, p);
            }

        }

        int m = sc.nextInt();

        for (int i = 0; i < m; i++) {
            String name = sc.next();
            String surname = sc.next();
            int budget = sc.nextInt();
            String ip = sc.next();
            String time = sc.next();
            String city = sc.next();
            int amount = sc.nextInt();

            Person p = new Person(name, surname, budget, ip, time, city, amount);

            int count = 0;
            Person maxSpender = null;
            int maxSpent = 0;

            for (int j = 0; j < tabela1.buckets.length; j++) {
                SLLNode<MapEntry<String, Person>> currNode = tabela1.buckets[j];
                while (currNode != null) {
                    MapEntry<String, Person> currEntry = currNode.element;
                    if (currEntry.key.equals(city)) {
                        count++;
                        Person currentPerson = currEntry.value;
                        if (currentPerson.amount >= maxSpent) {
                            maxSpent = currentPerson.amount;
                            maxSpender = currentPerson;
                        }
                    }
                    currNode = currNode.succ;
                }
            }
            System.out.println("City: " + city + " has the following number of customers:");
            System.out.println(count);
            if (maxSpender != null) {
                System.out.println("The user who spent the most purchasing for that city is:");
                System.out.println(maxSpender.name + " " + maxSpender.surname + " with salary " + maxSpender.budget + " from address " + maxSpender.ip + " who spent " + maxSpender.amount);
                System.out.println();
            }
        }
    }
}
