package Kolokvium2.Heshiranje;

import java.util.*;

public class cityBudzet {
    static class CBHT<K extends Comparable<K>, E> {

        // An object of class CBHT is a closed-bucket hash table, containing
        // entries of class MapEntry.
        private SLLNode<MapEntry<K, E>>[] buckets;

        @SuppressWarnings("unchecked")
        public CBHT(int m) {
            // Construct an empty CBHT with m buckets.
            buckets = (SLLNode<MapEntry<K, E>>[]) new SLLNode[m];
        }

        private int hash(K key) {
            // Translate key to an index of the array buckets.
            return Math.abs(key.hashCode()) % buckets.length;
        }

        public SLLNode<MapEntry<K, E>> search(K targetKey) {
            // Find which if any node of this CBHT contains an entry whose key is equal to targetKey.
            // Return a link to that node (or null if there is none).
            int b = hash(targetKey);
            SLLNode<MapEntry<K, E>> currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(targetKey)) return currNode;
                else currNode = currNode.succ;
            }
            return null;
        }

        public void insert(K key, E val) {
            // Insert the entry <key, val> into this CBHT.
            // If entry with same key exists, overwrite it.
            MapEntry<K, E> newEntry = new MapEntry<>(key, val);
            int b = hash(key);
            SLLNode<MapEntry<K, E>> currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(key)) {
                    // Make newEntry replace the existing entry ...
                    currNode.element = newEntry;
                    return;
                } else currNode = currNode.succ;
            }
            // Insert newEntry at the front of the SLL in bucket b ...
            buckets[b] = new SLLNode<>(newEntry, buckets[b]);
        }

        public void delete(K key) {
            // Delete the entry (if any) whose key is equal to key from this CBHT.
            int b = hash(key);
            SLLNode<MapEntry<K, E>> predNode = null, currNode = buckets[b];
            while (currNode != null) {
                MapEntry<K, E> currEntry = currNode.element;
                if (currEntry.key.equals(key)) {
                    if (predNode == null) buckets[b] = currNode.succ;
                    else predNode.succ = currNode.succ;
                    return;
                } else {
                    predNode = currNode;
                    currNode = currNode.succ;
                }
            }
        }

        public String toString() {
            String temp = "";
            for (int i = 0; i < buckets.length; i++) {
                temp += i + ":";
                SLLNode<MapEntry<K, E>> curr = buckets[i];
                while (curr != null) {
                    temp += curr.element.toString() + " ";
                    curr = curr.succ;
                }
                temp += "\n";
            }
            return temp;
        }
    }

    static class MapEntry<K extends Comparable<K>, E> {
        // Each MapEntry object is a pair consisting of a key (a Comparable object)
        // and a value (an arbitrary object).
        K key;
        E value;

        public MapEntry(K key, E val) {
            this.key = key;
            this.value = val;
        }

        public String toString() {
            return "<" + key + "," + value + ">";
        }
    }

    static class SLLNode<E> {
        protected E element;
        protected SLLNode<E> succ;

        public SLLNode(E elem, SLLNode<E> succ) {
            this.element = elem;
            this.succ = succ;
        }

        @Override
        public String toString() {
            return element.toString();
        }
    }

    static class Person {
        String name, surname;
        int budget;
        String ip, time, city;
        int price;

        public Person(String name, String surname, int budget, String ip, String time, String city, int price) {
            this.name = name;
            this.surname = surname;
            this.budget = budget;
            this.ip = ip;
            this.time = time;
            this.city = city;
            this.price = price;
        }

        //TODO : TUKA KE TREBA DA NAPRAEME KOJ OD TIA KE GO IMA NAJGOLEMIO IZNOS PLATNEO
        public boolean hasEnoughMoney() {
            if (budget >= price)
                return true;
            else
                return false;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        CBHT<String, Integer> table1 = new CBHT<>(n);
        CBHT<String, Person> table2 = new CBHT<>(n);

        for (int i = 0; i < n; i++) {
            Person p = new Person(sc.next(), sc.next(), sc.nextInt(), sc.next(), sc.next(), sc.next(), sc.nextInt());
            if (!p.hasEnoughMoney()) continue;
            SLLNode<MapEntry<String, Integer>> imaVekje = table1.search(p.city);
            if (imaVekje == null) {
                table1.insert(p.city, 1);
                table2.insert(p.city, p);
            } else {
                int brLugje = imaVekje.element.value;
                table1.insert(p.city, 1 + brLugje);
                Person person = table2.search(p.city).element.value;
                if (p.hasEnoughMoney() && person.hasEnoughMoney()) {
                    if (person.price < p.price) {
                        table2.insert(p.city, p);
                    }
                }
            }
        }
        int m = sc.nextInt();
        for (int i = 0; i < m; i++) {
            Person tester = new Person(sc.next(), sc.next(), sc.nextInt(), sc.next(), sc.next(), sc.next(), sc.nextInt());

            int brLugje = table1.search(tester.city).element.value;
            System.out.println("City: " + tester.city + " has the following number of customers:");
            System.out.println(brLugje);

            Person fastest = table2.search(tester.city).element.value;
            System.out.println("The user who spent the most purchasing for that city is:");
            System.out.println(fastest.name + " " + fastest.surname + " with salary " + fastest.budget + " from address " + fastest.ip + " who spent " + fastest.price);
            System.out.println();
        }
    }
}
